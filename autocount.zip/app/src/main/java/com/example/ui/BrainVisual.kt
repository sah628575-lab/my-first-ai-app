package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BrainVisual(totalCount: Int, modifier: Modifier = Modifier) {
    val health = maxOf(0, 100 - (totalCount / 5))
    
    val infiniteTransition = rememberInfiniteTransition(label = "brain_anim")
    
    // Pulse animation for healthy brain
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    
    // Gentle vibration for slight damage
    val slightVibrate by infiniteTransition.animateFloat(
        initialValue = -1.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(80, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "slight_vibrate"
    )
    
    // Violent vibration for damaged brain
    val violentVibrate by infiniteTransition.animateFloat(
        initialValue = -3.5f,
        targetValue = 3.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(45, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "violent_vibrate"
    )
    
    // Glitching tilt for rotting brain
    val slowRotation by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rotation"
    )

    // Determine state values based on totalCount:
    // healthy (0-50), slight damage (51-100), damaged (101-300), rotting (301+)
    val emojiState = remember(totalCount) {
        when {
            totalCount <= 50 -> EmojiStateVal("🧠", Color(0x3300E676))
            totalCount <= 100 -> EmojiStateVal("🤯", Color(0x44FF9800))
            totalCount <= 300 -> EmojiStateVal("🥴", Color(0x55FF5722))
            else -> EmojiStateVal("💀", Color(0x669C27B0))
        }
    }

    val (scaleMod, rotateMod, xOffset, yOffset) = when {
        totalCount <= 50 -> QuadValues(pulseScale, 0f, 0f, 0f)
        totalCount <= 100 -> QuadValues(1.0f, 0f, slightVibrate, slightVibrate)
        totalCount <= 300 -> QuadValues(0.95f, slightVibrate * 2f, violentVibrate, violentVibrate)
        else -> QuadValues(pulseScale, slowRotation, slightVibrate * 0.5f, slightVibrate * 0.5f)
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Glowing animated container
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(emojiState.color)
                .graphicsLayer(
                    scaleX = scaleMod,
                    scaleY = scaleMod,
                    rotationZ = rotateMod,
                    translationX = xOffset,
                    translationY = yOffset
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emojiState.emoji,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )
        }
        
        Spacer(modifier = Modifier.height(2.dp))
        
        Text(
            text = "Brain Health: $health%",
            color = if (health <= 30) Color(0xFFEF5350) else Color(0xFF524438),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 1.dp)
        )
    }
}

private data class EmojiStateVal(val emoji: String, val color: Color)
private data class QuadValues(val scale: Float, val rotate: Float, val dx: Float, val dy: Float)
