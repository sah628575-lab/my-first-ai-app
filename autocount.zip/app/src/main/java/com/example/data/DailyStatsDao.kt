package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyStatsDao {
    @Query("SELECT * FROM daily_stats WHERE date = :date")
    fun getDailyStats(date: String): Flow<DailyStats?>

    @Query("SELECT * FROM daily_stats WHERE date = :date")
    fun getDailyStatsSync(date: String): DailyStats?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDailyStats(stats: DailyStats)

    @Query("SELECT * FROM daily_stats ORDER BY date DESC")
    fun getAllStats(): Flow<List<DailyStats>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertScrollLog(entry: ScrollLogEntry)

    @Query("SELECT * FROM scroll_log ORDER BY timestamp DESC LIMIT 200")
    fun getAllScrollLogs(): Flow<List<ScrollLogEntry>>

    @Query("DELETE FROM scroll_log")
    suspend fun clearAllLogs()

    @Query("DELETE FROM daily_stats")
    suspend fun clearAllStats()

    @Query("UPDATE daily_stats SET dailyLimit = :limit WHERE date = :date")
    suspend fun updateDailyLimit(date: String, limit: Int)
}
