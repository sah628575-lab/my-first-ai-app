package com.example.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*

class GroupChallengeFragment : Fragment() {

    private val viewModel: AutoCountViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                val isDark by viewModel.isDarkModeEnabled.collectAsStateWithLifecycle()
                MyApplicationTheme(darkTheme = isDark) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        GroupChallengeScreenContent(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun GroupChallengeScreenContent(viewModel: AutoCountViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()

    if (currentUser == null) {
        // Display beautiful Authentication prompt screen
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
                border = BorderStroke(1.dp, PolishBorder),
                modifier = Modifier.fillMaxWidth().wrapContentHeight()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(PolishHighlight),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("👥", fontSize = 32.sp)
                    }
                    Text(
                        text = "Account Required for Challenges",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = PolishCharcoal,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "To join group challenges, sync progress with friends, and view leaderboards real-time, you must first create an optional cloud account.",
                        fontSize = 12.sp,
                        color = PolishMutedText,
                        textAlign = TextAlign.Center
                    )
                    
                    var email by remember { mutableStateOf("") }
                    var password by remember { mutableStateOf("") }
                    var isSignUpMode by remember { mutableStateOf(false) }
                    var authError by remember { mutableStateOf<String?>(null) }
                    var isLoading by remember { mutableStateOf(false) }
                    
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PolishPrimary,
                            unfocusedBorderColor = PolishSecondBorder
                        )
                    )
                    
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PolishPrimary,
                            unfocusedBorderColor = PolishSecondBorder
                        )
                    )
                    
                    if (authError != null) {
                        Text(authError!!, color = Color.Red, fontSize = 11.sp, textAlign = TextAlign.Center)
                    }
                    
                    Button(
                        onClick = {
                            if (email.isBlank() || password.isBlank()) {
                                authError = "Please fill in all fields"
                                return@Button
                            }
                            isLoading = true
                            authError = null
                            if (isSignUpMode) {
                                viewModel.signUpWithEmail(email, password) { success, err ->
                                    isLoading = false
                                    if (!success) authError = err ?: "Sign Up Failed"
                                }
                            } else {
                                viewModel.signInWithEmail(email, password) { success, err ->
                                    isLoading = false
                                    if (!success) authError = err ?: "Sign In Failed"
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = PolishPrimary)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        } else {
                            Text(if (isSignUpMode) "Create Account" else "Sign In", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    TextButton(
                        onClick = { isSignUpMode = !isSignUpMode }
                    ) {
                        Text(
                            text = if (isSignUpMode) "Already have an account? Sign In" else "New to AutoCount? Create Account",
                            fontSize = 12.sp,
                            color = PolishPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
        return
    }

    val inviteCode by viewModel.groupInviteCode.collectAsStateWithLifecycle()
    val members by viewModel.groupMembers.collectAsStateWithLifecycle()
    val messages by viewModel.groupMessages.collectAsStateWithLifecycle()
    val isConnected by viewModel.isSyncConnected.collectAsStateWithLifecycle()
    val syncTime by viewModel.lastSyncTime.collectAsStateWithLifecycle()

    var inviteInput by remember { mutableStateOf(TextFieldValue("")) }
    var chatOpen by remember { mutableStateOf(false) }
    var chatInput by remember { mutableStateOf("") }

    // Identify current leader (lowest count wins)
    val winner = remember(members) {
        members.minByOrNull { it.count }
    }

    if (inviteCode.isNullOrEmpty()) {
        // Welcome and Group Creation Screen
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(PolishHighlight),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = "Challenge Group",
                        tint = PolishDeepBrown,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Attention Peer Challenge",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = PolishCharcoal,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Challenge 3-4 peers to stay under their scroll. Low reels consumed wins daily with automated sync.",
                        fontSize = 13.sp,
                        color = PolishMutedText,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
                    border = BorderStroke(1.dp, PolishBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Join an Existing Challenge",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = PolishCharcoal
                        )

                        OutlinedTextField(
                            value = inviteInput,
                            onValueChange = { inviteInput = it },
                            label = { Text("6-Digit Invite Code") },
                            placeholder = { Text("e.g. CHAL27") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = PolishBackground,
                                unfocusedContainerColor = PolishBackground,
                                disabledContainerColor = PolishBackground,
                                focusedIndicatorColor = PolishPrimary,
                                unfocusedIndicatorColor = PolishSecondBorder
                            )
                        )

                        Button(
                            onClick = {
                                val code = inviteInput.text.trim()
                                if (code.length >= 3) {
                                    val success = viewModel.joinGroupChallenge(code)
                                    if (success) {
                                        Toast.makeText(context, "Joined challenge group $code!", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    Toast.makeText(context, "Please enter a valid invite code", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = PolishPrimary)
                        ) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Join")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Join Peer Challenge", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Divider(modifier = Modifier.weight(1f), color = PolishBorder)
                    Text(
                        text = "OR",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PolishMutedText,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    Divider(modifier = Modifier.weight(1f), color = PolishBorder)
                }
            }

            item {
                OutlinedButton(
                    onClick = {
                        viewModel.createGroupChallenge()
                        Toast.makeText(context, "Challenge group generated!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, PolishSecondBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PolishDeepBrown)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Create")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate Challenge Group", fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    } else {
        // Active Group Challenge Dashboard Screen
        Scaffold(
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { chatOpen = true },
                    containerColor = PolishPrimary,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = "Messages")
                }
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header with Invite Code & Leaving Option
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = PolishHighlight),
                        border = BorderStroke(1.dp, PolishBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Share, 
                                        contentDescription = "Share", 
                                        tint = PolishDeepBrown, 
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "Active Peer Challenge",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = PolishDeepBrown.copy(alpha = 0.8f)
                                    )
                                }
                                Text(
                                    text = inviteCode!!,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = PolishDeepBrown
                                )
                                Text(
                                    text = "Invite max 4 friends via this code",
                                    fontSize = 11.sp,
                                    color = PolishDeepBrown.copy(alpha = 0.7f)
                                )
                            }
                            Button(
                                onClick = {
                                    viewModel.leaveGroupChallenge()
                                    Toast.makeText(context, "Left challenge group", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF5350)),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("Leave", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }

                // Synchronization Status Card (Green/Red dot)
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
                        border = BorderStroke(1.dp, PolishBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Status Indicator
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(if (isConnected) Color(0xFF43A047) else Color(0xFFEF5350))
                                            .border(1.5.dp, Color.White, CircleShape)
                                    )
                                    Column {
                                        Text(
                                            text = if (isConnected) "Firestore Synchronized" else "Offline Diagnostics Mode",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = PolishCharcoal
                                        )
                                        Text(
                                            text = "Updates real-time every 30s • Last: $syncTime",
                                            fontSize = 10.sp,
                                            color = PolishMutedText
                                        )
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    IconButton(
                                        onClick = {
                                            viewModel.syncGroupChallengeWithFirestore()
                                            Toast.makeText(context, "Firestore Sync Requested!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Refresh, 
                                            contentDescription = "Sync", 
                                            tint = PolishPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = { viewModel.toggleSyncConnection() },
                                        contentPadding = PaddingValues(horizontal = 8.dp),
                                        border = BorderStroke(1.dp, PolishSecondBorder),
                                        modifier = Modifier.height(28.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PolishDeepBrown)
                                    ) {
                                        Text(if (isConnected) "Disconnect" else "Reconnect", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // Leaderboard Title & Trophy Banner
                item {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Text(
                                text = "Leaderboard (Max 4)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = PolishCharcoal
                            )
                            if (winner != null) {
                                val winnerText = if (winner.isYou) "You (Winning)" else "${winner.name} (Winning)"
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.EmojiEvents, 
                                        contentDescription = "Leader", 
                                        tint = Color(0xFFFFB300),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = winnerText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        color = PolishPrimary
                                    )
                                }
                            }
                        }
                        Text(
                            text = "Daily challenge target: lowest reel count wins. Stay offline!",
                            fontSize = 11.sp,
                            color = PolishMutedText
                        )
                    }
                }

                // ALL group members' cards displayed in a single screen layout
                items(members) { member ->
                    val isWinning = winner != null && member.id == winner.id
                    GroupMemberCard(member = member, isWinning = isWinning)
                }

                // Predefined quick motivation notes panel
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = PolishBackground),
                        border = BorderStroke(1.dp, PolishSecondBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                "Quick Accountability Prompts",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = PolishMutedText
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val prompts = listOf("Keep focus! Lock it 🔐", "Who is scrolling? 👀", "Great job today! 🙌")
                                prompts.forEach { text ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(PolishLightContainer)
                                            .border(BorderStroke(1.dp, PolishBorder), RoundedCornerShape(8.dp))
                                            .clickable {
                                                viewModel.sendGroupMessage(text)
                                                Toast.makeText(context, "Note broadcasted!", Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(vertical = 8.dp, horizontal = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = text,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PolishCharcoal,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Interactive Group Chat Overlay Bottom Sheet
    if (chatOpen) {
        AlertDialog(
            onDismissRequest = { chatOpen = false },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { chatOpen = false }) {
                    Text("Close Chat", fontWeight = FontWeight.Black, color = PolishDeepBrown)
                }
            },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.Chat, 
                        contentDescription = "Chat", 
                        tint = PolishPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Motivation Chat logs", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = PolishCharcoal)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    Divider(color = PolishBorder)
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages) { msg ->
                            val alignment = if (msg.isYou) Alignment.End else Alignment.Start
                            val bubbleColor = if (msg.isYou) PolishHighlight else PolishLightContainer
                            val textColor = if (msg.isYou) PolishDeepBrown else PolishCharcoal

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = alignment
                            ) {
                                Text(
                                    text = "${msg.senderName} • ${msg.timeString}",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = PolishMutedText,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(
                                            RoundedCornerShape(
                                                topStart = 12.dp,
                                                topEnd = 12.dp,
                                                bottomStart = if (msg.isYou) 12.dp else 0.dp,
                                                bottomEnd = if (msg.isYou) 0.dp else 12.dp
                                            )
                                        )
                                        .background(bubbleColor)
                                        .border(BorderStroke(1.dp, PolishBorder.copy(alpha = 0.5f)), RoundedCornerShape(12.dp))
                                        .padding(10.dp)
                                ) {
                                    Text(
                                        text = msg.text,
                                        fontSize = 12.sp,
                                        color = textColor,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = chatInput,
                            onValueChange = { chatInput = it },
                            placeholder = { Text("Send motivational message...", fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedIndicatorColor = PolishPrimary,
                                unfocusedIndicatorColor = PolishSecondBorder
                            )
                        )

                        IconButton(
                            onClick = {
                                if (chatInput.isNotBlank()) {
                                    viewModel.sendGroupMessage(chatInput)
                                    chatInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(PolishPrimary)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = PolishBackground
        )
    }
}

// GroupMemberCard Component for Peer Group Members display
@Composable
fun GroupMemberCard(member: AutoCountViewModel.GroupMember, isWinning: Boolean) {
    val progress = remember(member.count, member.limit) {
        if (member.limit > 0) member.count.toFloat() / member.limit.toFloat() else 0f
    }
    val safeProgress = progress.coerceIn(0f, 1f)

    val progressColor = when {
        progress >= 1.0f -> Color(0xFFEF5350) // Red if exceeded
        progress >= 0.75f -> Color(0xFFFFA726) // Orange if close
        else -> PolishPrimary // Classic Bronze theme
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
        border = BorderStroke(1.dp, if (isWinning) PolishPrimary else PolishBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Member Avatar Badge
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (isWinning) PolishHighlight else PolishBackground)
                    .border(1.5.dp, if (isWinning) PolishPrimary else PolishSecondBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (isWinning) {
                    Icon(
                        Icons.Default.EmojiEvents, 
                        contentDescription = "Trophy", 
                        tint = Color(0xFFFFB300),
                        modifier = Modifier.size(22.dp)
                    )
                } else {
                    Text(
                        text = member.name.take(1).uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = PolishDeepBrown
                    )
                }
            }

            // Member Info & Count
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = member.name,
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = PolishCharcoal
                        )
                        if (member.isYou) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(PolishHighlight)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("You", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = PolishDeepBrown)
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${member.count}/${member.limit} Reels",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (progress >= 1.0f) Color(0xFFEF5350) else PolishCharcoal
                        )
                        Text(
                            text = "${(progress * 100).toInt()}% Limit used",
                            fontSize = 9.sp,
                            color = PolishMutedText,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Custom Linear Progress bar
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape)
                        .background(PolishBorder)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(safeProgress)
                            .height(6.dp)
                            .clip(CircleShape)
                            .background(progressColor)
                    )
                }
            }
        }
    }
}
