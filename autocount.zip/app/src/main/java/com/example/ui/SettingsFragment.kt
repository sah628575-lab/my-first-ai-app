package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*

class SettingsFragment : Fragment() {

    private val viewModel: AutoCountViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                val isDark by viewModel.isDarkModeEnabled.collectAsStateWithLifecycle()
                MyApplicationTheme(darkTheme = isDark) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        SettingsScreenContent(viewModel = viewModel)
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshPermissionStates()
    }
}

@Composable
fun SettingsScreenContent(viewModel: AutoCountViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val todayStats by viewModel.todayStatsFlow.collectAsStateWithLifecycle()
    val limit = todayStats?.dailyLimit ?: getSavedLimit(context)

    var sliderValue by remember(limit) { mutableStateOf(limit.toFloat()) }

    val usageGranted by viewModel.isUsageGranted.collectAsStateWithLifecycle()
    val overlayGranted by viewModel.isOverlayGranted.collectAsStateWithLifecycle()
    val accessibilityEnabled by viewModel.isAccessibilityEnabled.collectAsStateWithLifecycle()

    val customThreshold by viewModel.customThresholdSec.collectAsStateWithLifecycle()
    val skipDoesntCount by viewModel.skipDoesntCount.collectAsStateWithLifecycle()

    val trackInstagram by viewModel.trackInstagramEnabled.collectAsStateWithLifecycle()
    val trackYoutube by viewModel.trackYoutubeEnabled.collectAsStateWithLifecycle()
    val trackFacebook by viewModel.trackFacebookEnabled.collectAsStateWithLifecycle()
    val trackPinterest by viewModel.trackPinterestEnabled.collectAsStateWithLifecycle()
    
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isLocalOnly by viewModel.isLocalOnly.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkModeEnabled.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Budget & Attention Settings",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        // 1. Aesthetics & Display Settings Card (Dark Mode Toggle)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Display & Aesthetics",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Customize the visual theme and presentation style of the application.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Dark Theme",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Choose a restful light-on-dark palette suited for nighttime mindfulness.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { viewModel.updateDarkMode(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = PolishPrimary,
                                checkedTrackColor = Color(0xFFF3D0B6),
                                uncheckedThumbColor = PolishMutedText,
                                uncheckedTrackColor = Color.White.copy(alpha = 0.4f)
                            )
                        )
                    }
                }
            }
        }

        // 2. Account & Connection Status Card (Firebase Sync indicator)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Cloud Backup & Synchronization",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Participate in real-time group challenges and keep your digital statistics backup secure.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sync & Connection status block
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when {
                                    isLocalOnly -> Color(0xFFFFF3E0) // Warning yellow
                                    currentUser == null -> Color(0xFFFFEBEE) // Red disconnect
                                    else -> Color(0xFFE8F5E9) // Green connected
                                }
                            )
                            .padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = when {
                                    isLocalOnly -> "⚠️"
                                    currentUser == null -> "🔴"
                                    else -> "🟢"
                                },
                                fontSize = 20.sp
                            )
                            Column {
                                Text(
                                    text = when {
                                        isLocalOnly -> "Privacy: Local Only Active"
                                        currentUser == null -> "Sync Status: Offline / Disconnected"
                                        else -> "Sync Status: Connected"
                                    },
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF2C2520) // Always high contrast dark on state bands
                                )
                                Text(
                                    text = when {
                                        isLocalOnly -> "No cloud transmissions will occur according to your privacy choice."
                                        currentUser == null -> "Progress is saved local-only. Accounts are required for global challenges."
                                        else -> "Logged in as ${currentUser?.email}. All counters are synchronized!"
                                    },
                                    fontSize = 11.sp,
                                    color = Color(0xFF5D4037)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (currentUser == null) {
                        var email by remember { mutableStateOf("") }
                        var password by remember { mutableStateOf("") }
                        var isSignUpMode by remember { mutableStateOf(false) }
                        var authError by remember { mutableStateOf<String?>(null) }
                        var isLoading by remember { mutableStateOf(false) }

                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PolishPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PolishPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )

                        if (authError != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(authError!!, color = Color.Red, fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    if (email.isBlank() || password.isBlank()) {
                                        authError = "Please fill in email & password"
                                        return@Button
                                    }
                                    isLoading = true
                                    authError = null
                                    if (isSignUpMode) {
                                        viewModel.signUpWithEmail(email, password) { success, err ->
                                            isLoading = false
                                            if (!success) authError = err ?: "Registration Failed"
                                        }
                                    } else {
                                        viewModel.signInWithEmail(email, password) { success, err ->
                                            isLoading = false
                                            if (!success) authError = err ?: "Sign In Failed"
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = PolishPrimary)
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                                } else {
                                    Text(if (isSignUpMode) "Register" else "Back up to Cloud", color = Color.White, fontSize = 13.sp)
                                }
                            }

                            TextButton(
                                onClick = { isSignUpMode = !isSignUpMode }
                            ) {
                                Text(
                                    text = if (isSignUpMode) "Sign In instead" else "Create Account",
                                    fontSize = 13.sp,
                                    color = PolishPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    viewModel.todayStatsFlow.value?.let { viewModel.backupStatsToCloud(it) }
                                    viewModel.restoreStatsFromCloud()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3E2723))
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Sync Now", modifier = Modifier.size(16.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Sync Now", fontSize = 12.sp, color = Color.White)
                            }

                            OutlinedButton(
                                onClick = { viewModel.signOut() },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, Color(0xFFEF5350)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF5350))
                            ) {
                                Text("Sign Out", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        // 3. Privacy Settings Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Privacy Controls",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Retain absolute control over how and where your scroll budgets are processed.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Store data locally only",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Bypass automatic cloud synchronization to keep all your attention metrics strictly on this device.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isLocalOnly,
                            onCheckedChange = { viewModel.updateLocalOnly(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = PolishPrimary,
                                checkedTrackColor = Color(0xFFF3D0B6),
                                uncheckedThumbColor = PolishMutedText,
                                uncheckedTrackColor = Color.White.copy(alpha = 0.4f)
                            )
                        )
                    }
                }
            }
        }

        // 4. Daily Limit Slider Card (10 to 500 limits, default 50)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Daily Reels Limit",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Restrict the maximum number of reels/shorts you can consume per day.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Current Limit:",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(PolishHighlight)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${sliderValue.toInt()} Reels",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PolishDeepBrown
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Slider(
                        value = sliderValue,
                        onValueChange = {
                            sliderValue = it
                        },
                        onValueChangeFinished = {
                            viewModel.updateDailyLimit(sliderValue.toInt())
                        },
                        valueRange = 10f..500f,
                        colors = SliderDefaults.colors(
                            thumbColor = PolishPrimary,
                            activeTrackColor = PolishPrimary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("10", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("250", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("500", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // 5. Custom Time Threshold Slider Card (1 to 10 seconds, default 3)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Video Time Threshold",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Require staying on a reel for a minimum duration. Skipping earlier avoids incrementing your budget.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Required Stay Time:",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(PolishHighlight)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "$customThreshold Seconds",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = PolishDeepBrown
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Slider(
                        value = customThreshold.toFloat(),
                        onValueChange = {
                            viewModel.updateCustomThreshold(it.toInt())
                        },
                        valueRange = 1f..10f,
                        steps = 8,
                        colors = SliderDefaults.colors(
                            thumbColor = PolishPrimary,
                            activeTrackColor = PolishPrimary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("1s", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("5s", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("10s", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), thickness = 1.dp, modifier = Modifier.padding(vertical = 14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Skip doesn't count",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Don't count reels skipped before meeting the required time threshold.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = skipDoesntCount,
                            onCheckedChange = { viewModel.updateSkipDoesntCount(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = PolishPrimary,
                                checkedTrackColor = Color(0xFFF3D0B6),
                                uncheckedThumbColor = PolishMutedText,
                                uncheckedTrackColor = Color.White.copy(alpha = 0.4f)
                            )
                        )
                    }
                }
            }
        }

        // 6. Apps to Track Toggle List Card (Instagram, YouTube Shorts, Facebook Reels, Pinterest)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Apps to track toggle list",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Toggle active background tracking on separate social and media networks.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    AppToggleRow(
                        appName = "Instagram",
                        symbol = "📸",
                        packageName = "com.instagram.android",
                        enabled = trackInstagram,
                        onCheckedChange = { viewModel.updateTrackApp("com.instagram.android", it) }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), thickness = 1.dp, modifier = Modifier.padding(vertical = 10.dp))

                    AppToggleRow(
                        appName = "YouTube Shorts",
                        symbol = "🎥",
                        packageName = "com.google.android.youtube",
                        enabled = trackYoutube,
                        onCheckedChange = { viewModel.updateTrackApp("com.google.android.youtube", it) }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), thickness = 1.dp, modifier = Modifier.padding(vertical = 10.dp))

                    AppToggleRow(
                        appName = "Facebook Reels",
                        symbol = "📘",
                        packageName = "com.facebook.katana",
                        enabled = trackFacebook,
                        onCheckedChange = { viewModel.updateTrackApp("com.facebook.katana", it) }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), thickness = 1.dp, modifier = Modifier.padding(vertical = 10.dp))

                    AppToggleRow(
                        appName = "Pinterest",
                        symbol = "📌",
                        packageName = "com.pinterest",
                        enabled = trackPinterest,
                        onCheckedChange = { viewModel.updateTrackApp("com.pinterest", it) }
                    )
                }
            }
        }

        // 7. Permissions Status Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Permission Controls",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Manage system level hooks necessary to track attention budgets and block apps.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    PermissionStatusRow(
                        title = "App Usage access",
                        granted = usageGranted,
                        onClick = {
                            try {
                                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                })
                            } catch (_: Exception) {}
                        }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), thickness = 1.dp, modifier = Modifier.padding(vertical = 12.dp))

                    PermissionStatusRow(
                        title = "Screen Overlay draw",
                        granted = overlayGranted,
                        onClick = {
                            try {
                                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                    context.startActivity(Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                                }
                            } catch (_: Exception) {}
                        }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), thickness = 1.dp, modifier = Modifier.padding(vertical = 12.dp))

                    PermissionStatusRow(
                        title = "Accessibility service",
                        granted = accessibilityEnabled,
                        onClick = {
                            try {
                                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                })
                            } catch (_: Exception) {}
                        }
                    )
                }
            }
        }

        // 8. Reset Limits & Clear Counters Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color(0xFFEF5350).copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Danger Zone",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFFEF5350)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Operations in this section permanently delete swipe metrics and historical track records.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.clearAllData() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFEF5350),
                            contentColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reset All Limits & Clear Counters", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

private fun getSavedLimit(context: Context): Int {
    return context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE).getInt("daily_limit", 50)
}

@Composable
fun PermissionStatusRow(title: String, granted: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text(
                text = if (granted) "Status: Allowed" else "Status: Denied",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (granted) Color(0xFF43A047) else Color(0xFFD32F2F)
            )
        }
        TextButton(onClick = onClick) {
            Text(
                text = if (granted) "Configure" else "Grant",
                color = PolishPrimary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun AppToggleRow(
    appName: String,
    symbol: String,
    packageName: String,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Text(symbol, fontSize = 14.sp)
            }
            Column {
                Text(
                    text = appName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = packageName,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(
            checked = enabled,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = PolishPrimary,
                checkedTrackColor = Color(0xFFF3D0B6),
                uncheckedThumbColor = PolishMutedText,
                uncheckedTrackColor = Color.White.copy(alpha = 0.4f)
            )
        )
    }
}
