package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DailyStats
import com.example.data.ScrollLogEntry
import com.example.service.AutoCountAccessibilityService
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppScreen {
    Tracker,
    Stats,
    Challenge,
    Settings
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CounterDashboardScreen(viewModel: AutoCountViewModel) {
    val context = LocalContext.current
    val todayStats by viewModel.todayStatsFlow.collectAsStateWithLifecycle()
    val scrollLogs by viewModel.scrollLogsFlow.collectAsStateWithLifecycle()

    val usageGranted by viewModel.isUsageGranted.collectAsStateWithLifecycle()
    val overlayGranted by viewModel.isOverlayGranted.collectAsStateWithLifecycle()
    val accessibilityEnabled by viewModel.isAccessibilityEnabled.collectAsStateWithLifecycle()
    val appUsageMap by viewModel.appUsageMinutes.collectAsStateWithLifecycle()

    val stats = todayStats ?: DailyStats(date = "Today", dailyLimit = 50)
    val totalCount = stats.totalCount
    val currentLimit = stats.dailyLimit

    var isOverlayActive by remember { mutableStateOf(AutoCountAccessibilityService.isOverlayEnabled) }

    LaunchedEffect(isOverlayActive) {
        AutoCountAccessibilityService.updateOverlayVisiblity(isOverlayActive)
    }

    var showOnboarding by remember {
        mutableStateOf(
            !context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
                .getBoolean("has_completed_onboarding2", false)
        )
    }

    if (showOnboarding) {
        OnboardingOverlayScreen(
            viewModel = viewModel,
            onComplete = {
                context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("has_completed_onboarding2", true)
                    .apply()
                showOnboarding = false
            }
        )
        return
    }

    val isAsyncLoading by viewModel.isAsyncLoading.collectAsStateWithLifecycle()
    val firebaseError by viewModel.firebaseError.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(AppScreen.Tracker) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Polished custom square bronze logo branding from HTML mockup
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(PolishPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                             )
                        }
                        Text(
                            text = "AutoCount",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = PolishCharcoal,
                            letterSpacing = (-0.5).sp
                        )
                    }
                },
                actions = {
                    // Right aligned accessibility status button from HTML mockup style
                    Box(
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (accessibilityEnabled) Color(0x1F00E676) else Color(0x1FEF5350))
                            .border(
                                1.5.dp, 
                                if (accessibilityEnabled) Color(0xFF00E676) else Color(0xFFEF5350), 
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (accessibilityEnabled) Color(0xFF00E676) else Color(0xFFEF5350))
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = PolishBackground,
                    titleContentColor = PolishCharcoal
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = PolishBackground,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .height(68.dp)
                    .border(BorderStroke(1.dp, PolishBorder.copy(alpha = 0.5f)))
            ) {
                NavigationBarItem(
                    selected = currentTab == AppScreen.Tracker,
                    onClick = { currentTab = AppScreen.Tracker },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Tracker") },
                    label = { Text("Tracker", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PolishDeepBrown,
                        selectedTextColor = PolishDeepBrown,
                        indicatorColor = PolishHighlight,
                        unselectedIconColor = PolishMutedText,
                        unselectedTextColor = PolishMutedText
                    )
                )
                NavigationBarItem(
                    selected = currentTab == AppScreen.Stats,
                    onClick = { currentTab = AppScreen.Stats },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = "Stats") },
                    label = { Text("Stats", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PolishDeepBrown,
                        selectedTextColor = PolishDeepBrown,
                        indicatorColor = PolishHighlight,
                        unselectedIconColor = PolishMutedText,
                        unselectedTextColor = PolishMutedText
                    )
                )
                NavigationBarItem(
                    selected = currentTab == AppScreen.Challenge,
                    onClick = { currentTab = AppScreen.Challenge },
                    icon = { Icon(Icons.Default.Group, contentDescription = "Challenge") },
                    label = { Text("Challenge", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PolishDeepBrown,
                        selectedTextColor = PolishDeepBrown,
                        indicatorColor = PolishHighlight,
                        unselectedIconColor = PolishMutedText,
                        unselectedTextColor = PolishMutedText
                    )
                )
                NavigationBarItem(
                    selected = currentTab == AppScreen.Settings,
                    onClick = { currentTab = AppScreen.Settings },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings", fontWeight = FontWeight.Bold, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PolishDeepBrown,
                        selectedTextColor = PolishDeepBrown,
                        indicatorColor = PolishHighlight,
                        unselectedIconColor = PolishMutedText,
                        unselectedTextColor = PolishMutedText
                    )
                )
            }
        },
        containerColor = PolishBackground
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            when (currentTab) {
                AppScreen.Tracker -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                    
                    // 1. Permission Setup Callout Card (Styled in warm Linen/Sand tones)
                    if (!usageGranted || !overlayGranted || !accessibilityEnabled) {
                        item {
                            PermissionSetupCard(
                                usageGranted = usageGranted,
                                overlayGranted = overlayGranted,
                                accessibilityEnabled = accessibilityEnabled,
                                onRequestUsage = {
                                    try {
                                        context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        })
                                    } catch (_: Exception) {}
                                },
                                onRequestOverlay = {
                                    try {
                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                            context.startActivity(Intent(
                                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                Uri.parse("package:${context.packageName}")
                                            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                                        }
                                    } catch (_: Exception) {}
                                },
                                onRequestAccessibility = {
                                    try {
                                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        })
                                    } catch (_: Exception) {}
                                }
                            )
                        }
                    }

                    // 2. High-fidelity Highlights Peach Donut Card
                    item {
                        DonutProgressGrid(
                            totalCount = totalCount,
                            limit = currentLimit,
                            onIncreaseLimit = { viewModel.setDailyLimit((currentLimit + 5).coerceAtMost(200)) },
                            onDecreaseLimit = { viewModel.setDailyLimit((currentLimit - 5).coerceAtLeast(5)) },
                            isOverlayActive = isOverlayActive,
                            onToggleOverlay = { isOverlayActive = it }
                        )
                    }

                    // 3. Grid breakdown cards styled with white canvas and light warm outlines
                    item {
                        PlatformBreakdownGrid(
                            stats = stats,
                            appUsageMap = appUsageMap,
                            limit = currentLimit
                        )
                    }

                    // 4. Interactive testing simulator
                    item {
                        SimulatorDashboardCard(
                            onSimulateSwipe = { platform -> viewModel.simulateReelScroll(platform) }
                        )
                    }

                    // 5. Recent History stream list header
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "RECENT SWIPES STREAM",
                                color = PolishMutedText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            if (scrollLogs.isNotEmpty()) {
                                TextButton(
                                    onClick = { viewModel.clearHistory() },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFEF5350))
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Clear logs", modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Clear Stream", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (scrollLogs.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                                    .border(BorderStroke(1.dp, PolishSecondBorder), RoundedCornerShape(16.dp))
                                    .background(Color.White),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "Empty",
                                        tint = PolishMutedText.copy(alpha = 0.5f),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Move your thumb! Swipes will stream here.",
                                        color = PolishMutedText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    } else {
                        items(scrollLogs) { log ->
                            SwipeLogItem(log = log)
                        }
                    }
                }
            }
            AppScreen.Stats -> {
                DashboardScreenContent(
                    viewModel = viewModel,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }
            AppScreen.Challenge -> {
                GroupChallengeScreenContent(
                    viewModel = viewModel,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }
            AppScreen.Settings -> {
                SettingsScreenContent(
                    viewModel = viewModel,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                )
            }
        }

        if (isAsyncLoading) {
            LinearProgressIndicator(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = innerPadding.calculateTopPadding())
                    .height(3.dp),
                color = PolishPrimary,
                trackColor = Color.Transparent
            )
        }

        firebaseError?.let { err ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = innerPadding.calculateTopPadding() + 8.dp, start = 16.dp, end = 16.dp)
                    .align(Alignment.TopCenter),
                shape = RoundedCornerShape(8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFDE8E8)),
                border = BorderStroke(1.dp, Color(0xFFE53935))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Error",
                        tint = Color(0xFFE53935),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = err,
                        color = Color(0xFFE53935),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { viewModel.firebaseError.value = null },
                        modifier = Modifier.size(18.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss",
                            tint = Color(0xFFE53935),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
fun PermissionSetupCard(
    usageGranted: Boolean,
    overlayGranted: Boolean,
    accessibilityEnabled: Boolean,
    onRequestUsage: () -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestAccessibility: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
        border = BorderStroke(1.dp, PolishBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "⚠️ Setup Status Required",
                color = PolishCharcoal,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Activate background scanners and overlays so AutoCount can read scroll gestures and display counters.",
                color = PolishMutedText,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ButtonRow(
                    title = "Accessibility: Autodetect Swipes",
                    description = "Required to find shorts",
                    isGranted = accessibilityEnabled,
                    onClick = onRequestAccessibility
                )
                ButtonRow(
                    title = "Display Over Other Apps: Counter Overlay",
                    description = "Required for real-time floating UI",
                    isGranted = overlayGranted,
                    onClick = onRequestOverlay
                )
                ButtonRow(
                    title = "Usage Access: Screen Minutes",
                    description = "Required to calculate time",
                    isGranted = usageGranted,
                    onClick = onRequestUsage
                )
            }
        }
    }
}

@Composable
fun ButtonRow(
    title: String,
    description: String,
    isGranted: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .border(BorderStroke(1.dp, PolishSecondBorder), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(
                text = title,
                color = PolishCharcoal,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = description,
                color = PolishMutedText,
                fontSize = 10.sp
            )
        }

        if (!isGranted) {
            Button(
                onClick = onClick,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PolishPrimary,
                    contentColor = Color.White
                ),
                modifier = Modifier.height(28.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Enable", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF00E676),
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Active",
                    color = Color(0xFF00E676),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun DonutProgressGrid(
    totalCount: Int,
    limit: Int,
    onIncreaseLimit: () -> Unit,
    onDecreaseLimit: () -> Unit,
    isOverlayActive: Boolean,
    onToggleOverlay: (Boolean) -> Unit
) {
    val ratio = if (limit > 0) totalCount.toFloat() / limit else 0f
    val sweepAngle = (ratio * 360f).coerceAtMost(360f)
    val animatedSweep by animateFloatAsState(
        targetValue = sweepAngle,
        animationSpec = tween(durationMillis = 800)
    )

    // The gauge color transitions smoothly
    val gaugeColor = when {
        totalCount >= limit -> Color(0xFFEF5350)
        ratio >= 0.75f -> Color(0xFFFF9800)
        else -> PolishPrimary
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = PolishHighlight),
        border = BorderStroke(1.dp, PolishBorder)
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "REELS WATCHED TODAY",
                color = PolishDarkGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Animated brain degradation visual
            BrainVisual(totalCount = totalCount)

            Spacer(modifier = Modifier.height(14.dp))

            // Donut gauge matching orange highlight tones
            Box(
                modifier = Modifier.size(175.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(140.dp)) {
                    // Back circular track
                    drawCircle(
                        color = Color(0xFFE4C3A8),
                        radius = size.minDimension / 2,
                        style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round)
                    )
                    // Polished neon sweep arc
                    drawArc(
                        color = gaugeColor,
                        startAngle = -90f,
                        sweepAngle = animatedSweep,
                        useCenter = false,
                        style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = String.format("%03d", totalCount),
                        fontSize = 58.sp,
                        fontWeight = FontWeight.Black,
                        color = PolishDeepBrown,
                        lineHeight = 58.sp
                    )
                    
                    Spacer(modifier = Modifier.height(2.dp))
                    
                    Text(
                        text = "⏱️ ${AutoCountAccessibilityService.timeRemainingSeconds.value}s left",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (AutoCountAccessibilityService.timeRemainingSeconds.value <= 10) Color(0xFFEF5350) else PolishDeepBrown.copy(alpha = 0.7f)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(PolishPrimary)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "max: ${String.format("%03d", limit)}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Status message
            val captionText = when {
                totalCount >= 500 -> "BRAIN ROT"
                totalCount >= 100 -> "Your brain is rotting!"
                totalCount >= limit -> "CRITICAL BREACH: Put the phone down!"
                ratio >= 0.75f -> "DANGER ZONE: Steer clear of reels!"
                totalCount == 0 -> "PERFECT! Pure clean mind today."
                else -> "MINDFUL PROGRESS: Focus active."
            }
            Text(
                text = captionText,
                color = if (totalCount >= 100 || totalCount >= limit) Color(0xFFD32F2F) else PolishDeepBrown,
                fontSize = if (totalCount >= 500) 20.sp else 12.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            HorizontalDivider(color = PolishBorder.copy(alpha = 0.5f), thickness = 1.dp, modifier = Modifier.padding(vertical = 14.dp))

            // Limit adjust row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Daily Limit Goal", 
                        color = PolishDeepBrown, 
                        fontSize = 13.sp, 
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Threshold of watched reels", 
                        color = PolishDarkGold, 
                        fontSize = 10.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IconButton(
                        onClick = onDecreaseLimit,
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.White.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Text("-", color = PolishDeepBrown, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }

                    Text(
                        text = "$limit",
                        color = PolishDeepBrown,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        modifier = Modifier.widthIn(min = 24.dp),
                        textAlign = TextAlign.Center
                    )

                    IconButton(
                        onClick = onIncreaseLimit,
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.White.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Text("+", color = PolishDeepBrown, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            HorizontalDivider(color = PolishBorder.copy(alpha = 0.5f), thickness = 1.dp, modifier = Modifier.padding(vertical = 14.dp))

            // Toggle Overlay Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Floating Tracker Panel", 
                        color = PolishDeepBrown, 
                        fontSize = 13.sp, 
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Render stats overlay on active apps", 
                        color = PolishDarkGold, 
                        fontSize = 10.sp
                    )
                }

                Switch(
                    checked = isOverlayActive,
                    onCheckedChange = onToggleOverlay,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = PolishPrimary,
                        checkedTrackColor = Color(0xFFF3D0B6),
                        uncheckedThumbColor = PolishMutedText,
                        uncheckedTrackColor = Color.White.copy(alpha = 0.4f)
                    )
                )
            }
        }
    }
}

@Composable
fun PlatformBreakdownGrid(
    stats: DailyStats,
    appUsageMap: Map<String, Long>,
    limit: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "ACTIVE TRACKING METRICS",
            color = PolishMutedText,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                PlatformCard(
                    title = "Instagram",
                    symbol = "📸",
                    count = stats.instagramCount,
                    minutes = appUsageMap["com.instagram.android"] ?: 0L,
                    badgeColor = Color(0x1FE1306C),
                    logoColor = Color(0xFFE1306C),
                    limit = limit
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                PlatformCard(
                    title = "YouTube",
                    symbol = "🎥",
                    count = stats.youtubeCount,
                    minutes = appUsageMap["com.google.android.youtube"] ?: 0L,
                    badgeColor = Color(0x1FFF0000),
                    logoColor = Color(0xFFFF0000),
                    limit = limit
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                PlatformCard(
                    title = "Facebook",
                    symbol = "📘",
                    count = stats.facebookCount,
                    minutes = appUsageMap["com.facebook.katana"] ?: 0L,
                    badgeColor = Color(0x1F3B5998),
                    logoColor = Color(0xFF3B5998),
                    limit = limit
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                PlatformCard(
                    title = "Pinterest",
                    symbol = "📌",
                    count = stats.pinterestCount,
                    minutes = appUsageMap["com.pinterest"] ?: 0L,
                    badgeColor = Color(0x1FBD081C),
                    logoColor = Color(0xFFBD081C),
                    limit = limit
                )
            }
        }
    }
}

@Composable
fun PlatformCard(
    title: String,
    symbol: String,
    count: Int,
    minutes: Long,
    badgeColor: Color,
    logoColor: Color,
    limit: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, PolishSecondBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title, 
                    fontSize = 12.sp, 
                    fontWeight = FontWeight.Bold, 
                    color = PolishCharcoal
                )
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(badgeColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = symbol, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "${String.format("%03d", count)} clips",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black,
                    color = PolishCharcoal,
                    letterSpacing = (-0.3).sp
                )

                Text(
                    text = "${minutes}m screen",
                    fontSize = 10.sp,
                    color = PolishMutedText,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Polished dynamic progress liner from HTML mockup
            val cardLimit = maxOf(limit / 4, 1)
            val fillPercent = (count.toFloat() / cardLimit).coerceAtMost(1f)
            
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(PolishSecondBorder)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fillPercent)
                        .clip(CircleShape)
                        .background(PolishPrimary)
                )
            }
        }
    }
}

@Composable
fun SimulatorDashboardCard(
    onSimulateSwipe: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
        border = BorderStroke(1.dp, PolishBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "⚡ Real-Time Swiping Simulator",
                color = PolishCharcoal,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Tap mock triggers below to simulate actual scroll swipes. This updates your database and counter immediately.",
                color = PolishMutedText,
                fontSize = 10.sp,
                lineHeight = 14.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { onSimulateSwipe("Instagram Reels") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE1306C)),
                    contentPadding = PaddingValues(horizontal = 4.dp),
                    modifier = Modifier.weight(1f).height(32.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Instagram", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                Button(
                    onClick = { onSimulateSwipe("YouTube Shorts") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0000)),
                    contentPadding = PaddingValues(horizontal = 4.dp),
                    modifier = Modifier.weight(1f).height(32.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("YouTube", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                Button(
                    onClick = { onSimulateSwipe("Facebook Reels") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B5998)),
                    contentPadding = PaddingValues(horizontal = 4.dp),
                    modifier = Modifier.weight(1f).height(32.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Facebook", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                Button(
                    onClick = { onSimulateSwipe("Pinterest Video") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD081C)),
                    contentPadding = PaddingValues(horizontal = 4.dp),
                    modifier = Modifier.weight(1f).height(32.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Pinterest", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun SwipeLogItem(log: ScrollLogEntry) {
    val formatter = remember { SimpleDateFormat("hh:mm:ss a", Locale.getDefault()) }
    val timeString = formatter.format(Date(log.timestamp))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
            .border(BorderStroke(1.dp, PolishSecondBorder), RoundedCornerShape(14.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val (badgeText, badgeColor) = when (log.platform) {
                "Instagram Reels" -> Pair("IG", Color(0xFFE1306C))
                "YouTube Shorts" -> Pair("YT", Color(0xFFFF0000))
                "Facebook Reels" -> Pair("FB", Color(0xFF3B5998))
                "Pinterest Video" -> Pair("PI", Color(0xFFBD081C))
                else -> Pair("RE", PolishPrimary)
            }

            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(badgeColor),
                contentAlignment = Alignment.Center
            ) {
                Text(text = badgeText, fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color.White)
            }

            Column {
                Text(
                    text = log.platform, 
                    color = PolishCharcoal, 
                    fontSize = 12.sp, 
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Automated scroll count +1", 
                    color = PolishMutedText, 
                    fontSize = 10.sp
                )
            }
        }

        Text(
            text = timeString,
            color = PolishMutedText,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingOverlayScreen(
    viewModel: AutoCountViewModel,
    onComplete: () -> Unit
) {
    val context = LocalContext.current
    var step by remember { mutableStateOf(1) }
    
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isSignUpMode by remember { mutableStateOf(true) }
    var authError by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = PolishBackground
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth().statusBarsPadding(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AUTO COUNT ONBOARDING",
                    fontWeight = FontWeight.Black,
                    fontSize = 11.sp,
                    color = PolishMutedText,
                    letterSpacing = 1.sp
                )
                
                Text(
                    text = "STEP $step OF 4",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = PolishPrimary
                )
            }

            // Step Content
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f).padding(vertical = 16.dp)
            ) {
                when (step) {
                    1 -> {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFF3E0)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("📊", fontSize = 56.sp)
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Text(
                            text = "How the Counter Works",
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp,
                            color = PolishCharcoal,
                            textAlign = TextAlign.Center
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Text(
                            text = "AutoCount runs a lightweight, battery-saving accessibility tracker to count real swipes through vertical video Reels and Shorts automatically. No more manual logging!",
                            fontSize = 13.sp,
                            color = PolishMutedText,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    2 -> {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFEBEE)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🎯", fontSize = 56.sp)
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Text(
                            text = "Set Mindful Limits",
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp,
                            color = PolishCharcoal,
                            textAlign = TextAlign.Center
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Text(
                            text = "Decide your daily swipe budget. When you're nearing your threshold, a non-intrusive floating tracker alerts you, giving you control back over addictive scrolling loops.",
                            fontSize = 13.sp,
                            color = PolishMutedText,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    3 -> {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE8F5E9)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("👥", fontSize = 56.sp)
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Text(
                            text = "Group Challenges & Sync",
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp,
                            color = PolishCharcoal,
                            textAlign = TextAlign.Center
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Text(
                            text = "Invite friends to custom live challenge groups! Keep each other accountable real-time with automatic cross-synchronized counters, leaderboards, and a support group chat.",
                            fontSize = 13.sp,
                            color = PolishMutedText,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                    }
                    4 -> {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(PolishHighlight),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("☁️", fontSize = 32.sp)
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Text(
                            text = "Cloud Account (Optional)",
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = PolishCharcoal,
                            textAlign = TextAlign.Center
                        )
                        
                        Text(
                            text = "Secure your progress, back up statistics to the cloud, and connect with friends in group challenges.",
                            fontSize = 11.sp,
                            color = PolishMutedText,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email Address", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PolishPrimary,
                                unfocusedBorderColor = PolishSecondBorder
                            )
                        )
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password", fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PolishPrimary,
                                unfocusedBorderColor = PolishSecondBorder
                            )
                        )

                        if (authError != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(authError!!, color = Color.Red, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }

            // Footer / Guidance Controls
            Column(
                modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (step < 4) {
                    Button(
                        onClick = { step++ },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PolishPrimary)
                    ) {
                        Text("Next Step", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    
                    TextButton(
                        onClick = { step = 4 }
                    ) {
                        Text("Skip Intro & Create Account", color = PolishMutedText, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                } else {
                    Button(
                        onClick = {
                            if (email.isBlank() || password.isBlank()) {
                                authError = "Please fill in email and password"
                                return@Button
                            }
                            isLoading = true
                            authError = null
                            if (isSignUpMode) {
                                viewModel.signUpWithEmail(email, password) { success, err ->
                                    isLoading = false
                                    if (success) {
                                        onComplete()
                                    } else {
                                        authError = err ?: "Sign Up Failed"
                                    }
                                }
                            } else {
                                viewModel.signInWithEmail(email, password) { success, err ->
                                    isLoading = false
                                    if (success) {
                                        onComplete()
                                    } else {
                                        authError = err ?: "Sign In Failed"
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PolishPrimary)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                        } else {
                            Text(if (isSignUpMode) "Register & Back Up Progress" else "Sign In & Restore Backup", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { isSignUpMode = !isSignUpMode }
                        ) {
                            Text(
                                text = if (isSignUpMode) "Already have an account? Sign In" else "Create New Cloud Account",
                                color = PolishPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = {
                                onComplete()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = PolishMutedText),
                            border = BorderStroke(1.dp, PolishBorder)
                        ) {
                            Text("Skip Account Setup", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

