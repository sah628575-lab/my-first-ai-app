package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scroll_log")
data class ScrollLogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val platform: String, // "Instagram Reels", "YouTube Shorts", "Facebook Reels", "Pinterest Video"
    val timestamp: Long = System.currentTimeMillis()
)
