package com.example.data

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AuthManager private constructor(private val context: Context) {

    private var auth: FirebaseAuth? = null
    private val _currentUser = MutableStateFlow<FirebaseUser?>(null)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    init {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:1234567890:android:abcdef123456")
                    .setApiKey("MockApiKeyForFirebaseLocalInitializationAvoidCrashes")
                    .setProjectId("mock-firebase-project-id")
                    .build()
                FirebaseApp.initializeApp(context, options)
            }
            auth = FirebaseAuth.getInstance()
            _currentUser.value = auth?.currentUser
            auth?.addAuthStateListener { firebaseAuth ->
                _currentUser.value = firebaseAuth.currentUser
            }
        } catch (e: Exception) {
            Log.e("AuthManager", "Firebase Auth init failed", e)
            _errorMessage.value = "Firebase Auth failed to initialize. Make sure google-services.json is configured."
        }
    }

    fun signUpWithEmail(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        val fbAuth = auth
        if (fbAuth == null) {
            onResult(false, "Firebase service is not initialized on this device.")
            return
        }
        fbAuth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    _currentUser.value = task.result?.user
                    onResult(true, null)
                } else {
                    val msg = task.exception?.localizedMessage ?: "Sign up failed"
                    _errorMessage.value = msg
                    onResult(false, msg)
                }
            }
    }

    fun signInWithEmail(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        val fbAuth = auth
        if (fbAuth == null) {
            onResult(false, "Firebase service is not initialized on this device.")
            return
        }
        fbAuth.signInWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    _currentUser.value = task.result?.user
                    onResult(true, null)
                } else {
                    val msg = task.exception?.localizedMessage ?: "Sign in failed"
                    _errorMessage.value = msg
                    onResult(false, msg)
                }
            }
    }

    fun signInWithGoogleToken(idToken: String, onResult: (Boolean, String?) -> Unit) {
        val fbAuth = auth
        if (fbAuth == null) {
            onResult(false, "Firebase service is not initialized on this device.")
            return
        }
        val credential = com.google.firebase.auth.GoogleAuthProvider.getCredential(idToken, null)
        fbAuth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    _currentUser.value = task.result?.user
                    onResult(true, null)
                } else {
                    val msg = task.exception?.localizedMessage ?: "Google sign-in failed"
                    _errorMessage.value = msg
                    onResult(false, msg)
                }
            }
    }

    fun signOut() {
        try {
            auth?.signOut()
            _currentUser.value = null
        } catch (e: Exception) {
            _errorMessage.value = e.localizedMessage
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    companion object {
        @Volatile
        private var INSTANCE: AuthManager? = null

        fun getInstance(context: Context): AuthManager {
            return INSTANCE ?: synchronized(this) {
                val instance = AuthManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
