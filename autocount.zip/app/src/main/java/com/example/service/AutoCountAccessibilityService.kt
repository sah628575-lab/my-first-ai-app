package com.example.service

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.savedstate.SavedStateRegistryOwner
import com.example.data.AppDatabase
import com.example.data.AutoCountRepository
import com.example.ui.BrainVisual
import com.example.data.DailyStats
import com.example.ui.theme.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AutoCountAccessibilityService : AccessibilityService(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private var windowManager: WindowManager? = null
    private var overlayView: ComposeView? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private lateinit var repository: AutoCountRepository
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var flowCollectionJob: Job? = null

    // For throttling scrolls per platform to avoid rapid over-counting
    private val lastScrollTimestamps = HashMap<String, Long>()
    private val COOLDOWN_MS = 1800L // Cool-down time between scroll increments

    private var activePackageName: String? = null
    private var blockingOverlayView: ComposeView? = null
    private var blockingLayoutParams: WindowManager.LayoutParams? = null

    private var currentActivePlatform: String? = null
    private var timerJob: Job? = null

    companion object {
        var isOverlayEnabled = true
        var isServiceConnected = false

        // Live memory states for rapid overlay syncing
        var currentCount = mutableStateOf(0)
        var dailyLimit = mutableStateOf(50)
        var instagramCount = mutableStateOf(0)
        var youtubeCount = mutableStateOf(0)
        var facebookCount = mutableStateOf(0)
        var pinterestCount = mutableStateOf(0)
        var timeRemainingSeconds = mutableStateOf(60) // formatted attention timer
        var isBypassed = mutableStateOf(false)

        // Custom Time Threshold features
        var customThresholdSec = mutableStateOf(3)
        var skipDoesntCount = mutableStateOf(true)
        var thresholdTimerSeconds = mutableStateOf(3)
        var isTimerCounting = mutableStateOf(false)

        // Tracked apps enabled states
        var trackInstagramEnabled = mutableStateOf(true)
        var trackYoutubeEnabled = mutableStateOf(true)
        var trackFacebookEnabled = mutableStateOf(true)
        var trackPinterestEnabled = mutableStateOf(true)

        @SuppressLint("StaticFieldLeak")
        private var instance: AutoCountAccessibilityService? = null

        fun updateOverlayVisiblity(visible: Boolean) {
            isOverlayEnabled = visible
            instance?.updateOverlayState(visible)
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        instance = this
        isServiceConnected = true

        val database = AppDatabase.getDatabase(this)
        repository = AutoCountRepository(database.dailyStatsDao)

        val prefs = getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        customThresholdSec.value = prefs.getInt("custom_threshold_sec", 3)
        skipDoesntCount.value = prefs.getBoolean("skip_doesnt_count", true)
        trackInstagramEnabled.value = prefs.getBoolean("track_com_instagram_android", true)
        trackYoutubeEnabled.value = prefs.getBoolean("track_com_google_android_youtube", true)
        trackFacebookEnabled.value = prefs.getBoolean("track_com_facebook_katana", true)
        trackPinterestEnabled.value = prefs.getBoolean("track_com_pinterest", true)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        recollectStats()

        // Active ticker counting down every 1 second and checking date change
        var activeDate = repository.getTodayDateString()
        serviceScope.launch {
            while (true) {
                kotlinx.coroutines.delay(1000L)
                val activePkg = activePackageName ?: ""
                val isTrackedAppInForeground = blockedPackages.contains(activePkg)
                // Battery Optimization: Only count down if a tracked app is currently focused/active
                if (isTrackedAppInForeground && timeRemainingSeconds.value > 0) {
                    timeRemainingSeconds.value -= 1
                }

                // Midnight detection
                val currentDate = repository.getTodayDateString()
                if (currentDate != activeDate) {
                    activeDate = currentDate
                    isBypassed.value = false
                    timeRemainingSeconds.value = 60
                    recollectStats()
                }
            }
        }
    }

    private fun recollectStats() {
        flowCollectionJob?.cancel()
        val prefs = getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        val defaultLimit = prefs.getInt("daily_limit", 50)
        flowCollectionJob = serviceScope.launch {
            repository.getTodayStats().collectLatest { stats ->
                val s = stats ?: DailyStats(date = repository.getTodayDateString(), dailyLimit = defaultLimit)
                val prevCount = currentCount.value
                currentCount.value = s.totalCount
                dailyLimit.value = s.dailyLimit
                instagramCount.value = s.instagramCount
                youtubeCount.value = s.youtubeCount
                facebookCount.value = s.facebookCount
                pinterestCount.value = s.pinterestCount

                // Automatically reset current reel timer back to 60 seconds when a new reel counts
                if (s.totalCount > prevCount) {
                    timeRemainingSeconds.value = 60
                }

                // Show Limit Reached Toast Alert when limit milestone is crossed
                if (s.totalCount >= s.dailyLimit && prevCount < s.dailyLimit && s.dailyLimit > 0) {
                    serviceScope.launch(Dispatchers.Main) {
                        try {
                            android.widget.Toast.makeText(
                                this@AutoCountAccessibilityService,
                                "⚠️ Daily Limit Reached! Swipe Screen Blocked.",
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        } catch (_: Exception) {}
                    }
                }

                checkBlockingOverlay()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        isServiceConnected = true
        updateOverlayState(isOverlayEnabled)
    }

    private val blockedPackages = setOf(
        "com.instagram.android",
        "com.google.android.youtube",
        "com.facebook.katana",
        "com.pinterest"
    )

    private fun checkBlockingOverlay() {
        val activePkg = activePackageName ?: ""
        val limit = dailyLimit.value
        val total = currentCount.value
        val shouldBlock = blockedPackages.contains(activePkg) && total >= limit && !isBypassed.value

        serviceScope.launch(Dispatchers.Main) {
            if (shouldBlock) {
                if (blockingOverlayView == null) {
                    showBlockingOverlay()
                }
            } else {
                hideBlockingOverlay()
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showBlockingOverlay() {
        val wm = windowManager ?: return
        if (blockingOverlayView != null) return

        val typeParam = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        blockingLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            typeParam,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        blockingOverlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@AutoCountAccessibilityService)
            setViewTreeSavedStateRegistryOwner(this@AutoCountAccessibilityService)
            setViewTreeViewModelStoreOwner(this@AutoCountAccessibilityService)
            setContent {
                BlockingOverlayCompose()
            }
        }

        try {
            wm.addView(blockingOverlayView, blockingLayoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideBlockingOverlay() {
        if (blockingOverlayView != null) {
            try {
                windowManager?.removeView(blockingOverlayView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            blockingOverlayView = null
            blockingLayoutParams = null
        }
    }

    @Composable
    private fun BlockingOverlayCompose() {
        val total = currentCount.value
        var showWarningDialog by remember { mutableStateOf(false) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xE60F0F10)), // Dark eye-safe twilight background with translucency
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Warning Brain Rot Graphics indicator decoration
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(Color(0x33EF5350)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "💀",
                        fontSize = 52.sp
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(
                    text = "REELS LIMIT BREACHED",
                    color = Color(0xFFEF5350),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "You've scrolled $total reels today. Stop now!",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Save your attention span. Build actual real skills. Don't let algorithms digest your time.",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(36.dp))

                Button(
                    onClick = {
                        performGlobalAction(GLOBAL_ACTION_HOME)
                        hideBlockingOverlay()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E676),
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Text(
                        text = "Back to Sanity",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Unlock anyway",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clickable { showWarningDialog = true }
                        .padding(8.dp)
                )
            }

            if (showWarningDialog) {
                AlertDialog(
                    onDismissRequest = { showWarningDialog = false },
                    title = {
                        Text(
                            text = "⚠️ WARNING: Proceed to Rot?",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFEF5350)
                        )
                    },
                    text = {
                        Text(
                            text = "You are about to bypass your daily attention barrier. Continuing will degrade your focus, shrink your attention span, and feed the algorithm. Are you absolutely sure you want to proceed?",
                            color = Color.DarkGray
                        )
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                isBypassed.value = true
                                showWarningDialog = false
                                checkBlockingOverlay()
                            }
                        ) {
                            Text(
                                "Yes, Proceed anyway",
                                color = Color(0xFFEF5350),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    dismissButton = {
                        TextButton(
                            onClick = {
                                showWarningDialog = false
                                performGlobalAction(GLOBAL_ACTION_HOME)
                                hideBlockingOverlay()
                            }
                        ) {
                            Text("No, Back to Sanity", color = Color.Gray)
                        }
                    }
                )
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return
        activePackageName = packageName
        checkBlockingOverlay()

        // Map packages to user-friendly titles
        val platform = when {
            packageName.contains("instagram") -> "Instagram Reels"
            packageName.contains("youtube") -> "YouTube Shorts"
            packageName.contains("facebook") -> "Facebook Reels"
            packageName.contains("pinterest") -> "Pinterest Video"
            else -> return
        }

        // Check if tracking is disabled for this app
        val isEnabled = when (platform) {
            "Instagram Reels" -> trackInstagramEnabled.value
            "YouTube Shorts" -> trackYoutubeEnabled.value
            "Facebook Reels" -> trackFacebookEnabled.value
            "Pinterest Video" -> trackPinterestEnabled.value
            else -> false
        }
        if (!isEnabled) {
            // Cancel current active timer if the active tracked app is disabled
            timerJob?.cancel()
            isTimerCounting.value = false
            return
        }

        // Only register scroll gesture triggers
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            val now = System.currentTimeMillis()
            val lastTime = lastScrollTimestamps[platform] ?: 0L
            if (now - lastTime >= COOLDOWN_MS) {
                lastScrollTimestamps[platform] = now
                onReelSwipedOrEntered(platform)
            }
        }
    }

    private fun onReelSwipedOrEntered(platform: String) {
        currentActivePlatform = platform
        
        // Cancel any existing countdown job
        timerJob?.cancel()
        
        val threshold = customThresholdSec.value
        thresholdTimerSeconds.value = threshold
        
        if (skipDoesntCount.value) {
            isTimerCounting.value = true
            // Toast when counter begins
            serviceScope.launch(Dispatchers.Main) {
                try {
                    android.widget.Toast.makeText(
                        this@AutoCountAccessibilityService,
                        "Counter started: stay $threshold seconds to count",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                } catch (_: Exception) {}
            }
            timerJob = serviceScope.launch(Dispatchers.Main) {
                while (thresholdTimerSeconds.value > 0) {
                    kotlinx.coroutines.delay(1000L)
                    thresholdTimerSeconds.value -= 1
                }
                isTimerCounting.value = false
                // Threshold met! Count the reel
                serviceScope.launch(Dispatchers.IO) {
                    repository.incrementReelCount(platform)
                    serviceScope.launch(Dispatchers.Main) {
                        try {
                            android.widget.Toast.makeText(
                                this@AutoCountAccessibilityService,
                                "Swapped! Reel counted.",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } catch (_: Exception) {}
                    }
                }
            }
        } else {
            isTimerCounting.value = false
            serviceScope.launch(Dispatchers.IO) {
                repository.incrementReelCount(platform)
                serviceScope.launch(Dispatchers.Main) {
                    try {
                        android.widget.Toast.makeText(
                            this@AutoCountAccessibilityService,
                            "Swapped! Reel counted.",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    } catch (_: Exception) {}
                }
            }
        }
    }

    override fun onInterrupt() {
        // Accessibility interrupted
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceConnected = false
        removeOverlay()
        flowCollectionJob?.cancel()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        instance = null
    }

    private fun updateOverlayState(visible: Boolean) {
        if (visible) {
            if (overlayView == null) {
                createOverlay()
            }
        } else {
            removeOverlay()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createOverlay() {
        val wm = windowManager ?: return
        val context = this

        val typeParam = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            typeParam,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 220
        }

        overlayView = ComposeView(context).apply {
            setViewTreeLifecycleOwner(this@AutoCountAccessibilityService)
            setViewTreeSavedStateRegistryOwner(this@AutoCountAccessibilityService)
            setViewTreeViewModelStoreOwner(this@AutoCountAccessibilityService)
            setContent {
                FloatingOverlayCompose()
            }
        }

        try {
            wm.addView(overlayView, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeOverlay() {
        if (overlayView != null) {
            try {
                windowManager?.removeView(overlayView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            overlayView = null
            layoutParams = null
        }
    }

    @Composable
    private fun FloatingOverlayCompose() {
        val total = currentCount.value
        val limit = dailyLimit.value
        val ratio = if (limit > 0) total.toFloat() / limit else 0f
        var isExpanded by remember { mutableStateOf(false) }

        // Alert styling based on current usage
        val (themeColor, message) = when {
            total >= limit -> Pair(Color(0xFFEF5350), "DROP THE PHONE")
            ratio >= 0.75f -> Pair(Color(0xFFFF9800), "DANGER ZONE")
            else -> Pair(Color(0xFF00E676), "MIND SCROLL")
        }

        Box(
            modifier = Modifier
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDrag = { change, dragAmount ->
                            change.consume()
                            layoutParams?.let { params ->
                                params.x += dragAmount.x.toInt()
                                params.y += dragAmount.y.toInt()
                                try {
                                    windowManager?.updateViewLayout(overlayView, params)
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    )
                }
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 240.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xEB1A1C1E),
                                Color(0xEB121315)
                            )
                        )
                    )
                    .clickable { isExpanded = !isExpanded }
                    .padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (!isExpanded) {
                    // Minimized compact badge
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(themeColor)
                        )
                        Text(
                            text = "AutoCount:",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = String.format("%03d / %03d", total, limit),
                            color = themeColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "⏱️ ${timeRemainingSeconds.value}s",
                            color = if (timeRemainingSeconds.value <= 10) Color(0xFFEF5350) else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (isTimerCounting.value) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFFFB300))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "⏳ ${thresholdTimerSeconds.value}s",
                                    color = Color.Black,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                } else {
                    // Expanded detailed dashboard
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⚡ Real-Time Tracking",
                            color = themeColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Minimize",
                            tint = Color.White.copy(alpha = 0.5f),
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { isExpanded = false }
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Animated brain degradation visible directly on top of third-party apps
                    BrainVisual(totalCount = total)

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "⏱️ Reel Timer: ${timeRemainingSeconds.value}s left",
                        color = if (timeRemainingSeconds.value <= 10) Color(0xFFEF5350) else Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    if (isTimerCounting.value) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFFFFB300))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "⏳ SCREEN COUNTDOWN: ${thresholdTimerSeconds.value}s before count",
                                color = Color.Black,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    } else if (skipDoesntCount.value && currentActivePlatform != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "✓ Threshold met / Ready",
                            color = Color(0xFF00E676),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = String.format("%03d", total),
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black
                    )

                    Text(
                        text = message,
                        color = themeColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (total >= 100) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (total >= 500) "BRAIN ROT" else "Your brain is rotting!",
                            color = Color(0xFFEF5350),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        PlatformStatRow(name = "Instagram", count = instagramCount.value)
                        PlatformStatRow(name = "YouTube", count = youtubeCount.value)
                        PlatformStatRow(name = "Facebook", count = facebookCount.value)
                        PlatformStatRow(name = "Pinterest", count = pinterestCount.value)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Drag to reposition overlay",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 8.sp
                    )
                }
            }
        }
    }

    @Composable
    private fun PlatformStatRow(name: String, count: Int) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = name, color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
            Text(text = "$count reels", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}
