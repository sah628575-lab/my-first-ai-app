package com.example

import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import androidx.activity.viewModels
import androidx.fragment.app.FragmentActivity
import com.example.ui.CounterFragment
import com.example.ui.AutoCountViewModel

class MainActivity : FragmentActivity() {

    private val viewModel: AutoCountViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Programmatic frame layout container to avoid XML layout requirements
        val containerId = View.generateViewId()
        val frameLayout = FrameLayout(this).apply {
            id = containerId
        }
        setContentView(frameLayout)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(containerId, CounterFragment())
                .commit()
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshPermissionStates()
    }
}
