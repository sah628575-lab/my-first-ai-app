package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_stats")
data class DailyStats(
    @PrimaryKey val date: String, // Format: "yyyy-MM-dd"
    val instagramCount: Int = 0,
    val youtubeCount: Int = 0,
    val facebookCount: Int = 0,
    val pinterestCount: Int = 0,
    val totalCount: Int = 0,
    val dailyLimit: Int = 25 // Default limit of reels/shorts per day
)
