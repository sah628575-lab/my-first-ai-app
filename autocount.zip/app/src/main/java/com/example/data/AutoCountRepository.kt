package com.example.data

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AutoCountRepository(private val dao: DailyStatsDao) {

    fun getTodayStats(): Flow<DailyStats?> {
        return dao.getDailyStats(getTodayDateString())
    }

    fun getStatsForDate(date: String): Flow<DailyStats?> {
        return dao.getDailyStats(date)
    }

    fun getAllStats(): Flow<List<DailyStats>> {
        return dao.getAllStats()
    }

    fun getAllLogs(): Flow<List<ScrollLogEntry>> {
        return dao.getAllScrollLogs()
    }

    suspend fun clearLogs() {
        dao.clearAllLogs()
    }

    suspend fun setDailyLimit(limit: Int) {
        val today = getTodayDateString()
        val currentStats = dao.getDailyStatsSync(today)
        if (currentStats == null) {
            dao.insertDailyStats(DailyStats(date = today, dailyLimit = limit))
        } else {
            dao.updateDailyLimit(today, limit)
        }
    }

    suspend fun incrementReelCount(platform: String) {
        val today = getTodayDateString()
        val currentStats = dao.getDailyStatsSync(today) ?: DailyStats(date = today)
        
        val updatedStats = when (platform) {
            "Instagram Reels" -> currentStats.copy(
                instagramCount = currentStats.instagramCount + 1,
                totalCount = currentStats.totalCount + 1
            )
            "YouTube Shorts" -> currentStats.copy(
                youtubeCount = currentStats.youtubeCount + 1,
                totalCount = currentStats.totalCount + 1
            )
            "Facebook Reels" -> currentStats.copy(
                facebookCount = currentStats.facebookCount + 1,
                totalCount = currentStats.totalCount + 1
            )
            "Pinterest Video" -> currentStats.copy(
                pinterestCount = currentStats.pinterestCount + 1,
                totalCount = currentStats.totalCount + 1
            )
            else -> currentStats.copy(
                totalCount = currentStats.totalCount + 1
            )
        }
        
        dao.insertDailyStats(updatedStats)
        dao.insertScrollLog(ScrollLogEntry(platform = platform))
    }

    fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }
}
