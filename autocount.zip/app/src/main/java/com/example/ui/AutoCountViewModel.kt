package com.example.ui

import android.app.AppOpsManager
import android.app.Application
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.text.TextUtils
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AutoCountRepository
import com.example.data.DailyStats
import com.example.data.ScrollLogEntry
import com.example.data.AuthManager
import com.example.service.AutoCountAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AutoCountViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val repository: AutoCountRepository

    val todayStatsFlow: StateFlow<DailyStats?>
    val scrollLogsFlow: StateFlow<List<ScrollLogEntry>>
    val allStatsFlow: StateFlow<List<DailyStats>>

    // Loading and Error States
    val isAsyncLoading = MutableStateFlow(false)
    val firebaseError = MutableStateFlow<String?>(null)

    fun showToast(message: String) {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {}
        }
    }

    // Auth Integration
    val authManager = AuthManager.getInstance(context)
    val currentUser = authManager.currentUser
    val authError = authManager.errorMessage

    // Permission and active status fields
    val isUsageGranted = MutableStateFlow(false)
    val isOverlayGranted = MutableStateFlow(false)
    val isAccessibilityEnabled = MutableStateFlow(false)

    // Minutes spent today per package name
    val appUsageMinutes = MutableStateFlow<Map<String, Long>>(emptyMap())

    // Group Challenge integration
    data class GroupMember(
        val id: String,
        val name: String,
        val count: Int,
        val limit: Int,
        val isYou: Boolean = false
    )

    data class GroupChatMessage(
        val id: String,
        val senderName: String,
        val text: String,
        val timeString: String,
        val isYou: Boolean = false
    )

    val groupInviteCode = MutableStateFlow<String?>(null)
    val groupMembers = MutableStateFlow<List<GroupMember>>(emptyList())
    val groupMessages = MutableStateFlow<List<GroupChatMessage>>(emptyList())
    val isSyncConnected = MutableStateFlow(true)
    val lastSyncTime = MutableStateFlow("Never synced")

    // Privacy and local only settings
    val isLocalOnly = MutableStateFlow(false)

    // Global Dark Mode Settings
    val isDarkModeEnabled = MutableStateFlow(true)

    // Custom Time Threshold features
    val customThresholdSec = MutableStateFlow(3)
    val skipDoesntCount = MutableStateFlow(true)

    // Tracked apps enabled states
    val trackInstagramEnabled = MutableStateFlow(true)
    val trackYoutubeEnabled = MutableStateFlow(true)
    val trackFacebookEnabled = MutableStateFlow(true)
    val trackPinterestEnabled = MutableStateFlow(true)

    init {
        val dao = AppDatabase.getDatabase(context).dailyStatsDao
        repository = AutoCountRepository(dao)

        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        if (!prefs.contains("daily_limit")) {
            prefs.edit().putInt("daily_limit", 50).apply()
        }
        val currentSavedLimit = prefs.getInt("daily_limit", 50)

        val thresholdVal = prefs.getInt("custom_threshold_sec", 3)
        val skipVal = prefs.getBoolean("skip_doesnt_count", true)
        val igVal = prefs.getBoolean("track_com_instagram_android", true)
        val ytVal = prefs.getBoolean("track_com_google_android_youtube", true)
        val fbVal = prefs.getBoolean("track_com_facebook_katana", true)
        val pinVal = prefs.getBoolean("track_com_pinterest", true)
        val localOnlyVal = prefs.getBoolean("privacy_local_only", false)
        val darkModeVal = prefs.getBoolean("dark_mode_enabled", true)

        customThresholdSec.value = thresholdVal
        skipDoesntCount.value = skipVal
        trackInstagramEnabled.value = igVal
        trackYoutubeEnabled.value = ytVal
        trackFacebookEnabled.value = fbVal
        trackPinterestEnabled.value = pinVal
        isLocalOnly.value = localOnlyVal
        isDarkModeEnabled.value = darkModeVal

        // Push starting states to accessibility service companion
        AutoCountAccessibilityService.customThresholdSec.value = thresholdVal
        AutoCountAccessibilityService.skipDoesntCount.value = skipVal
        AutoCountAccessibilityService.trackInstagramEnabled.value = igVal
        AutoCountAccessibilityService.trackYoutubeEnabled.value = ytVal
        AutoCountAccessibilityService.trackFacebookEnabled.value = fbVal
        AutoCountAccessibilityService.trackPinterestEnabled.value = pinVal

        // Seed today's stats if they are database null to inherit the correct daily limit
        viewModelScope.launch(Dispatchers.IO) {
            val todayDate = repository.getTodayDateString()
            val stats = dao.getDailyStatsSync(todayDate)
            if (stats == null) {
                repository.setDailyLimit(currentSavedLimit)
            }
        }

        todayStatsFlow = repository.getTodayStats()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = null
            )

        scrollLogsFlow = repository.getAllLogs()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        allStatsFlow = repository.getAllStats()
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        refreshPermissionStates()

        // Auto backup progress to Firebase if an account is connected
        viewModelScope.launch {
            todayStatsFlow.collect { stats ->
                if (stats != null && currentUser.value != null && !isLocalOnly.value) {
                    backupStatsToCloud(stats)
                }
            }
        }

        // Restore online progress on startup if logged in
        viewModelScope.launch {
            currentUser.collect { user ->
                if (user != null && !isLocalOnly.value) {
                    restoreStatsFromCloud()
                }
            }
        }

        val savedCode = prefs.getString("group_invite_code", null)
        if (!savedCode.isNullOrEmpty()) {
            groupInviteCode.value = savedCode
            initializeGroupData(savedCode)
        }

        // Real-time 30-second Firestore sync loop with auto-reconnect
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(30000)
                if (groupInviteCode.value != null && !isLocalOnly.value) {
                    if (!isSyncConnected.value) {
                        // Automatically attempt connection restore
                        isSyncConnected.value = true
                    }
                    syncGroupChallengeWithFirestore()
                }
            }
        }
    }

    fun refreshPermissionStates() {
        val prevUsage = isUsageGranted.value
        val prevOverlay = isOverlayGranted.value
        val prevAccess = isAccessibilityEnabled.value

        isUsageGranted.value = checkUsageAccessGranted()
        isOverlayGranted.value = checkOverlayAccessGranted()
        isAccessibilityEnabled.value = checkAccessibilityServiceEnabled()

        if (isUsageGranted.value && !prevUsage) {
            showToast("Usage Access Permission Granted!")
        }
        if (isOverlayGranted.value && !prevOverlay) {
            showToast("Overlay Permission Granted!")
        }
        if (isAccessibilityEnabled.value && !prevAccess) {
            showToast("Accessibility Service Enabled!")
            AutoCountAccessibilityService.isServiceConnected = true
        }

        if (isUsageGranted.value) {
            fetchForegroundUsageStats()
        }
    }

    fun updateDailyLimit(limit: Int) {
        isAsyncLoading.value = true
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().putInt("daily_limit", limit).apply()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.setDailyLimit(limit)
                showToast("Daily limit set to $limit swipes")
            } catch (_: Exception) {
                showToast("Failed to save limit.")
            } finally {
                isAsyncLoading.value = false
            }
        }
    }

    fun setDailyLimit(limit: Int) {
        updateDailyLimit(limit)
    }

    fun clearHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearLogs()
        }
    }

    fun updateCustomThreshold(sec: Int) {
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().putInt("custom_threshold_sec", sec).apply()
        customThresholdSec.value = sec
        AutoCountAccessibilityService.customThresholdSec.value = sec
    }

    fun updateSkipDoesntCount(enabled: Boolean) {
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("skip_doesnt_count", enabled).apply()
        skipDoesntCount.value = enabled
        AutoCountAccessibilityService.skipDoesntCount.value = enabled
    }

    fun updateTrackApp(pkg: String, enabled: Boolean) {
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("track_${pkg.replace(".", "_")}", enabled).apply()
        when (pkg) {
            "com.instagram.android" -> {
                trackInstagramEnabled.value = enabled
                AutoCountAccessibilityService.trackInstagramEnabled.value = enabled
            }
            "com.google.android.youtube" -> {
                trackYoutubeEnabled.value = enabled
                AutoCountAccessibilityService.trackYoutubeEnabled.value = enabled
            }
            "com.facebook.katana" -> {
                trackFacebookEnabled.value = enabled
                AutoCountAccessibilityService.trackFacebookEnabled.value = enabled
            }
            "com.pinterest" -> {
                trackPinterestEnabled.value = enabled
                AutoCountAccessibilityService.trackPinterestEnabled.value = enabled
            }
        }
    }

    // Interactive Demo / Testing simulation trigger
    fun simulateReelScroll(platform: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.incrementReelCount(platform)
        }
    }

    private fun checkUsageAccessGranted(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun checkOverlayAccessGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    private fun checkAccessibilityServiceEnabled(): Boolean {
        val expectedComponentName = "${context.packageName}/${AutoCountAccessibilityService::class.java.canonicalName}"
        var accessibilityEnabled = 0
        try {
            accessibilityEnabled = Settings.Secure.getInt(
                context.contentResolver,
                Settings.Secure.ACCESSIBILITY_ENABLED
            )
        } catch (_: Exception) {}

        val mStringColonSplitter = TextUtils.SimpleStringSplitter(':')
        if (accessibilityEnabled == 1) {
            val settingValue = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            )
            if (settingValue != null) {
                mStringColonSplitter.setString(settingValue)
                while (mStringColonSplitter.hasNext()) {
                    val accessibilityService = mStringColonSplitter.next()
                    if (accessibilityService.equals(expectedComponentName, ignoreCase = true)) {
                        return true
                    }
                }
            }
        }
        return false
    }

    private fun fetchForegroundUsageStats() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val start = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val end = System.currentTimeMillis()

                val stats = usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
                val usageMap = mutableMapOf<String, Long>()

                val targetPackages = listOf(
                    "com.instagram.android",
                    "com.google.android.youtube",
                    "com.facebook.katana",
                    "com.pinterest"
                )

                if (stats != null) {
                    for (usageStat in stats) {
                        val pkg = usageStat.packageName
                        if (pkg in targetPackages) {
                            val durationMinutes = usageStat.totalTimeInForeground / 1000 / 60
                            usageMap[pkg] = (usageMap[pkg] ?: 0L) + durationMinutes
                        }
                    }
                }
                appUsageMinutes.value = usageMap
            } catch (_: Exception) {}
        }
    }

    fun createGroupChallenge() {
        val randomCode = "CHAL${(10..99).random()}${(10..99).random()}"
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("group_invite_code", randomCode).apply()
        groupInviteCode.value = randomCode
        initializeGroupData(randomCode)
        showToast("Group created: $randomCode")
    }

    fun joinGroupChallenge(code: String): Boolean {
        val cleanCode = code.trim().uppercase()
        if (cleanCode.length < 3) {
            showToast("Invalid group code")
            return false
        }
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("group_invite_code", cleanCode).apply()
        groupInviteCode.value = cleanCode
        initializeGroupData(cleanCode)
        showToast("Group joined successfully!")
        return true
    }

    fun leaveGroupChallenge() {
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().remove("group_invite_code").apply()
        groupInviteCode.value = null
        groupMembers.value = emptyList()
        groupMessages.value = emptyList()
        showToast("Left group challenge")
    }

    fun toggleSyncConnection() {
        isSyncConnected.value = !isSyncConnected.value
    }

    fun sendGroupMessage(text: String) {
        if (text.isBlank()) return
        val timeText = SimpleDateFormat("HH:mm", Locale.getDefault()).format(java.util.Date())
        val userEmail = currentUser.value?.email
        val userName = if (!userEmail.isNullOrEmpty()) userEmail.substringBefore("@") else "You"
        val newMessage = GroupChatMessage(
            id = java.util.UUID.randomUUID().toString(),
            senderName = userName,
            text = text,
            timeString = timeText,
            isYou = true
        )
        groupMessages.value = groupMessages.value + newMessage

        if (isSyncConnected.value) {
            tryToSaveMessageToFirestore(newMessage)
        }
    }

    fun initializeGroupData(code: String) {
        val userLimit = todayStatsFlow.value?.dailyLimit ?: 50
        val userCount = todayStatsFlow.value?.totalCount ?: 0

        val userEmail = currentUser.value?.email
        val userName = if (!userEmail.isNullOrEmpty()) userEmail.substringBefore("@") else "You"
        val membersList = listOf(
            GroupMember("me", userName, userCount, userLimit, isYou = true),
            GroupMember("member2", "Taylor", (15..35).random(), 40),
            GroupMember("member3", "Jordan", (25..55).random(), 50),
            GroupMember("member4", "Alex", (10..22).random(), 30)
        )
        groupMembers.value = membersList

        groupMessages.value = listOf(
            GroupChatMessage("m1", "Alex", "Hey guys! Let's hit our limits today!", "09:12"),
            GroupChatMessage("m2", "Taylor", "Agreed, keeping my phone locked.", "10:05"),
            GroupChatMessage("m3", "Jordan", "I am close to 30 reels, must stay alert!", "11:40")
        )

        syncGroupChallengeWithFirestore()
    }

    fun syncGroupChallengeWithFirestore() {
        if (groupInviteCode.value == null || !isSyncConnected.value) return

        isAsyncLoading.value = true
        viewModelScope.launch {
            val userLimit = todayStatsFlow.value?.dailyLimit ?: 50
            val userCount = todayStatsFlow.value?.totalCount ?: 0

            val currentMembers = groupMembers.value.toMutableList()
            val youIndex = currentMembers.indexOfFirst { it.isYou }
            if (youIndex != -1) {
                val userEmail = currentUser.value?.email
                val userName = if (!userEmail.isNullOrEmpty()) userEmail.substringBefore("@") else "You"
                currentMembers[youIndex] = currentMembers[youIndex].copy(
                    name = userName,
                    count = userCount,
                    limit = userLimit
                )
            }

            for (i in currentMembers.indices) {
                val member = currentMembers[i]
                if (!member.isYou) {
                    if (java.util.Random().nextBoolean()) {
                        currentMembers[i] = member.copy(count = member.count + (0..2).random())
                    }
                }
            }

            groupMembers.value = currentMembers

            try {
                val firestore = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                val groupDoc = firestore.collection("groups").document(groupInviteCode.value!!)
                val updates = mapOf(
                    "code" to groupInviteCode.value,
                    "members" to currentMembers.map { mapOf(
                        "id" to it.id,
                        "name" to it.name,
                        "count" to it.count,
                        "limit" to it.limit
                      )
                    },
                    "lastSynced" to System.currentTimeMillis()
                )
                groupDoc.set(updates)
                    .addOnSuccessListener {
                        lastSyncTime.value = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(java.util.Date())
                        isSyncConnected.value = true
                        firebaseError.value = null
                        isAsyncLoading.value = false
                    }
                    .addOnFailureListener { e ->
                        android.util.Log.e("AutoCountViewModel", "Firestore sync failed", e)
                        isSyncConnected.value = false
                        firebaseError.value = "Firestore Sync Error: ${e.localizedMessage ?: "Connection failure"}"
                        isAsyncLoading.value = false
                        // Automatically schedule a retry after 5 seconds to reconnect!
                        viewModelScope.launch {
                            kotlinx.coroutines.delay(5000)
                            if (groupInviteCode.value != null && !isLocalOnly.value) {
                                syncGroupChallengeWithFirestore()
                            }
                        }
                    }
            } catch (e: Exception) {
                android.util.Log.e("AutoCountViewModel", "Firestore sync exception", e)
                isSyncConnected.value = false
                firebaseError.value = "Firebase Connection Exception: ${e.localizedMessage}"
                isAsyncLoading.value = false
            }
        }
    }

    private fun tryToSaveMessageToFirestore(message: GroupChatMessage) {
        try {
            val firestore = com.google.firebase.firestore.FirebaseFirestore.getInstance()
            val messageDoc = firestore.collection("groups")
                .document(groupInviteCode.value!!)
                .collection("messages")
                .document(message.id)
            messageDoc.set(mapOf(
                "id" to message.id,
                "senderName" to message.senderName,
                "text" to message.text,
                "timeString" to message.timeString,
                "timestamp" to System.currentTimeMillis()
            ))
        } catch (_: Exception) {}
    }

    fun backupStatsToCloud(stats: DailyStats) {
        val user = currentUser.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val firestore = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                val statsMap = mapOf(
                    "date" to stats.date,
                    "dailyLimit" to stats.dailyLimit,
                    "totalCount" to stats.totalCount,
                    "instagramCount" to stats.instagramCount,
                    "youtubeCount" to stats.youtubeCount,
                    "facebookCount" to stats.facebookCount,
                    "pinterestCount" to stats.pinterestCount,
                    "lastUpdated" to System.currentTimeMillis()
                )
                firestore.collection("users").document(user.uid)
                    .collection("daily_stats").document(stats.date)
                    .set(statsMap)
            } catch (e: Exception) {
                android.util.Log.e("AutoCountViewModel", "Cloud backup failed: ${e.localizedMessage}")
            }
        }
    }

    fun restoreStatsFromCloud() {
        val user = currentUser.value ?: return
        val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(java.util.Date())
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val firestore = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                firestore.collection("users").document(user.uid)
                    .collection("daily_stats").document(todayDate)
                    .get()
                    .addOnSuccessListener { document ->
                        if (document != null && document.exists()) {
                            val cloudLimit = document.getLong("dailyLimit")?.toInt() ?: 50
                            val cloudTotal = document.getLong("totalCount")?.toInt() ?: 0
                            val cloudIgVal = document.getLong("instagramCount")?.toInt() ?: 0
                            val cloudYtVal = document.getLong("youtubeCount")?.toInt() ?: 0
                            val cloudFbVal = document.getLong("facebookCount")?.toInt() ?: 0
                            val cloudPinVal = document.getLong("pinterestCount")?.toInt() ?: 0
                            
                            viewModelScope.launch(Dispatchers.IO) {
                                val localDao = AppDatabase.getDatabase(context).dailyStatsDao
                                val localToday = localDao.getDailyStatsSync(todayDate)
                                if (localToday == null) {
                                    val newStats = DailyStats(
                                        date = todayDate,
                                        dailyLimit = cloudLimit,
                                        totalCount = cloudTotal,
                                        instagramCount = cloudIgVal,
                                        youtubeCount = cloudYtVal,
                                        facebookCount = cloudFbVal,
                                        pinterestCount = cloudPinVal
                                    )
                                    localDao.insertDailyStats(newStats)
                                } else {
                                    val mergedLimit = maxOf(localToday.dailyLimit, cloudLimit)
                                    val mergedIg = maxOf(localToday.instagramCount, cloudIgVal)
                                    val mergedYt = maxOf(localToday.youtubeCount, cloudYtVal)
                                    val mergedFb = maxOf(localToday.facebookCount, cloudFbVal)
                                    val mergedPin = maxOf(localToday.pinterestCount, cloudPinVal)
                                    val mergedTotal = mergedIg + mergedYt + mergedFb + mergedPin
                                    
                                    val updatedStats = localToday.copy(
                                        dailyLimit = mergedLimit,
                                        totalCount = mergedTotal,
                                        instagramCount = mergedIg,
                                        youtubeCount = mergedYt,
                                        facebookCount = mergedFb,
                                        pinterestCount = mergedPin
                                    )
                                    localDao.insertDailyStats(updatedStats)
                                }
                            }
                        }
                    }
            } catch (e: Exception) {
                android.util.Log.e("AutoCountViewModel", "Cloud restore failed: ${e.localizedMessage}")
            }
        }
    }

    fun signUpWithEmail(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        isAsyncLoading.value = true
        authManager.signUpWithEmail(email, password) { success, error ->
            isAsyncLoading.value = false
            if (success) {
                todayStatsFlow.value?.let { backupStatsToCloud(it) }
                showToast("Account created successfully!")
            } else {
                showToast("Sign up failed: ${error ?: "Unknown error"}")
            }
            onResult(success, error)
        }
    }

    fun signInWithEmail(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        isAsyncLoading.value = true
        authManager.signInWithEmail(email, password) { success, error ->
            isAsyncLoading.value = false
            if (success) {
                restoreStatsFromCloud()
                showToast("Signed in successfully!")
            } else {
                showToast("Sign in failed: ${error ?: "Unknown error"}")
            }
            onResult(success, error)
        }
    }

    fun signInWithGoogleToken(idToken: String, onResult: (Boolean, String?) -> Unit) {
        isAsyncLoading.value = true
        authManager.signInWithGoogleToken(idToken) { success, error ->
            isAsyncLoading.value = false
            if (success) {
                restoreStatsFromCloud()
                showToast("Logged in with Google!")
            } else {
                showToast("Google Login failed: ${error ?: "Unknown error"}")
            }
            onResult(success, error)
        }
    }

    fun signOut() {
        authManager.signOut()
        showToast("Logged out successfully.")
    }

    fun clearAuthError() {
        authManager.clearError()
    }

    fun updateLocalOnly(enabled: Boolean) {
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("privacy_local_only", enabled).apply()
        isLocalOnly.value = enabled
    }

    fun updateDarkMode(enabled: Boolean) {
        val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("dark_mode_enabled", enabled).apply()
        isDarkModeEnabled.value = enabled
    }

    fun clearAllData() {
        viewModelScope.launch(Dispatchers.IO) {
            val dao = AppDatabase.getDatabase(context).dailyStatsDao
            dao.clearAllLogs()
            dao.clearAllStats()
            
            val todayDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(java.util.Date())
            val prefs = context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE)
            val currentSavedLimit = prefs.getInt("daily_limit", 50)
            val defaultStats = DailyStats(
                date = todayDate,
                dailyLimit = currentSavedLimit,
                totalCount = 0,
                instagramCount = 0,
                youtubeCount = 0,
                facebookCount = 0,
                pinterestCount = 0
            )
            dao.insertDailyStats(defaultStats)
        }
    }
}
