package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = PolishPrimary,
    secondary = PolishMutedText,
    tertiary = PolishHighlight,
    background = PolishCharcoal,
    surface = Color(0xFF1E1D1A),
    onBackground = Color.White,
    onSurface = Color.White
  )

private val LightColorScheme =
  lightColorScheme(
    primary = PolishPrimary,
    onPrimary = Color.White,
    primaryContainer = PolishHighlight,
    onPrimaryContainer = PolishDeepBrown,
    secondary = PolishMutedText,
    onSecondary = Color.White,
    background = PolishBackground,
    onBackground = PolishCharcoal,
    surface = PolishLightContainer,
    onSurface = PolishCharcoal,
    surfaceVariant = PolishLightContainer,
    onSurfaceVariant = PolishMutedText,
    outline = PolishBorder
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false, // Force Professional Polish light theme as per HTML mockup
  dynamicColor: Boolean = false, // Avoid system dynamic color override to maintain brand consistency
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
