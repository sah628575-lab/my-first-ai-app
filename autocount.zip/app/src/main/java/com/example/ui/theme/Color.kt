package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Professional Polish Theme Colors
val PolishBackground = Color(0xFFFCFAF8)
val PolishPrimary = Color(0xFF8B5000)
val PolishCharcoal = Color(0xFF1D1B16)
val PolishHighlight = Color(0xFFFCE0CA)
val PolishDeepBrown = Color(0xFF2A1800)
val PolishMutedText = Color(0xFF7A7468)
val PolishLightContainer = Color(0xFFF4F0E8)
val PolishBorder = Color(0xFFD9D1C3)
val PolishSecondBorder = Color(0xFFEBE3D7)
val PolishDarkGold = Color(0xFF524438)

