package com.example.ui

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.DailyStats
import com.example.ui.theme.*
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.ValueFormatter
import java.text.SimpleDateFormat
import java.util.*

class DashboardFragment : Fragment() {

    private val viewModel: AutoCountViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                val isDark by viewModel.isDarkModeEnabled.collectAsStateWithLifecycle()
                MyApplicationTheme(darkTheme = isDark) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        DashboardScreenContent(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

// Custom formatter to map indices to day labels
class ChartLabelFormatter(private val labels: Array<String>) : ValueFormatter() {
    override fun getFormattedValue(value: Float): String {
        val index = value.toInt()
        return if (index >= 0 && index < labels.size) {
            labels[index]
        } else {
            ""
        }
    }
}

@Composable
fun DashboardScreenContent(viewModel: AutoCountViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val allStats by viewModel.allStatsFlow.collectAsStateWithLifecycle()
    val todayStats by viewModel.todayStatsFlow.collectAsStateWithLifecycle()

    // 1. Core measurements & calculations
    val todayCount = todayStats?.totalCount ?: 0
    val currentLimit = todayStats?.dailyLimit ?: getSavedLimit(context)

    // Calculate last 7 calendar days (chronological)
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val labelSdf = SimpleDateFormat("E", Locale.getDefault())
    
    val last7Days = remember {
        (0..6).map { offset ->
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, -offset)
            val dateStr = sdf.format(cal.time)
            val label = labelSdf.format(cal.time)
            Pair(dateStr, label)
        }.reversed()
    }

    // 2. 7-Day Average
    val avg7Days = remember(allStats, last7Days) {
        val total = last7Days.sumOf { pair ->
            allStats.find { it.date == pair.first }?.totalCount ?: 0
        }
        total.toFloat() / 7f
    }

    // 3. Time saved calculation today
    val timeSavedSeconds = remember(todayCount, currentLimit) {
        val diff = currentLimit - todayCount
        if (diff > 0) diff * 30 else 0
    }
    val minutesSaved = timeSavedSeconds / 60
    val secondsSaved = timeSavedSeconds % 60

    // 4. Streak counter showing consecutive days below limit
    val streakCount = remember(allStats) {
        var streak = 0
        val sortedStats = allStats.sortedByDescending { it.date }
        for (stat in sortedStats) {
            if (stat.totalCount <= stat.dailyLimit) {
                streak++
            } else {
                break
            }
        }
        streak
    }

    // 5. Best vs Worst Day
    val bestDay = remember(allStats) {
        allStats.filter { it.totalCount > 0 }.minByOrNull { it.totalCount }
    }
    val worstDay = remember(allStats) {
        allStats.maxByOrNull { it.totalCount }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Attention Stats Dashboard",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = PolishCharcoal
                )
                Text(
                    text = "Historical digital hygiene diagnostics",
                    fontSize = 12.sp,
                    color = PolishMutedText
                )
            }
        }

        // Today's stats summary cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Today count card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
                    border = BorderStroke(1.dp, PolishBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.Star,
                                contentDescription = "Today",
                                tint = PolishPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                "Today's Reels",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PolishMutedText
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$todayCount",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = PolishCharcoal
                        )
                        Text(
                            text = "Limit: $currentLimit",
                            fontSize = 11.sp,
                            color = PolishMutedText,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // 7-day average card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
                    border = BorderStroke(1.dp, PolishBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = "Average",
                                tint = PolishPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                "7-Day Average",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PolishMutedText
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = String.format(Locale.getDefault(), "%.1f", avg7Days),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            color = PolishCharcoal
                        )
                        Text(
                            text = "Reels per day",
                            fontSize = 11.sp,
                            color = PolishMutedText,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Saved Attention & Streak Indicator row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Focus time saved today card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
                    border = BorderStroke(1.dp, PolishBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = "Saved Time",
                                tint = Color(0xFF43A047),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                "Attention Saved",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PolishMutedText
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (timeSavedSeconds > 0) "${minutesSaved}m ${secondsSaved}s" else "0s",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = PolishCharcoal
                        )
                        Text(
                            text = "Based on limit vs actual",
                            fontSize = 10.sp,
                            color = PolishMutedText,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Clean-streak card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = PolishHighlight),
                    border = BorderStroke(1.dp, PolishBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = "Streak",
                                tint = PolishDeepBrown,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                "Mindful Streak",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PolishDeepBrown.copy(alpha = 0.7f)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$streakCount Days",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = PolishDeepBrown
                        )
                        Text(
                            text = "Consecutive smart days",
                            fontSize = 10.sp,
                            color = PolishDeepBrown.copy(alpha = 0.7f),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // MPAndroidChart Week Graph Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
                border = BorderStroke(1.dp, PolishBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Weekly Scroll Diagnostics",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = PolishCharcoal
                    )
                    Text(
                        text = "Reels consumed daily (Last 7 Days)",
                        fontSize = 11.sp,
                        color = PolishMutedText,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    AndroidView(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        factory = { ctx ->
                            BarChart(ctx).apply {
                                description.isEnabled = false
                                legend.isEnabled = false
                                setDrawGridBackground(false)
                                setDrawBarShadow(false)
                                setTouchEnabled(false)
                                
                                xAxis.apply {
                                    position = XAxis.XAxisPosition.BOTTOM
                                    setDrawGridLines(false)
                                    textColor = android.graphics.Color.parseColor("#7A7468")
                                    textSize = 10f
                                    granularity = 1f
                                }
                                
                                axisLeft.apply {
                                    textColor = android.graphics.Color.parseColor("#7A7468")
                                    textSize = 10f
                                    setDrawGridLines(true)
                                    gridColor = android.graphics.Color.parseColor("#EBE3D7")
                                    axisMinimum = 0f
                                }
                                axisRight.isEnabled = false
                            }
                        },
                        update = { barChart ->
                            val entries = last7Days.mapIndexed { index, pair ->
                                val count = allStats.find { it.date == pair.first }?.totalCount ?: 0
                                BarEntry(index.toFloat(), count.toFloat())
                            }
                            val labels = last7Days.map { it.second }.toTypedArray()
                            
                            barChart.xAxis.valueFormatter = ChartLabelFormatter(labels)
                            
                            val dataSet = BarDataSet(entries, "Reels").apply {
                                color = android.graphics.Color.parseColor("#8B5000")
                                valueTextColor = android.graphics.Color.parseColor("#1D1B16")
                                valueTextSize = 9f
                            }
                            
                            barChart.data = BarData(dataSet).apply {
                                barWidth = 0.45f
                            }
                            barChart.invalidate()
                        }
                    )
                }
            }
        }

        // Best Day vs Worst Day Comparison Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = PolishLightContainer),
                border = BorderStroke(1.dp, PolishBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Limit Comparisons",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = PolishCharcoal,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Best control day card
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(PolishBackground)
                                .border(BorderStroke(1.dp, PolishSecondBorder), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(
                                    Icons.Default.ArrowDownward,
                                    contentDescription = "Best Day",
                                    tint = Color(0xFF43A047),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text("Best Control Day", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PolishMutedText)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            if (bestDay != null) {
                                Text(
                                    text = "${bestDay.totalCount} Reels",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PolishCharcoal
                                )
                                Text(
                                    text = formatDateString(bestDay.date),
                                    fontSize = 11.sp,
                                    color = PolishMutedText,
                                    fontWeight = FontWeight.SemiBold
                                )
                            } else {
                                Text("No historic logs", fontSize = 13.sp, color = PolishMutedText, fontWeight = FontWeight.Medium)
                            }
                        }

                        // Worst scroll day card
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(PolishBackground)
                                .border(BorderStroke(1.dp, PolishSecondBorder), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(
                                    Icons.Default.ArrowUpward,
                                    contentDescription = "Worst Day",
                                    tint = Color(0xFFEF5350),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text("Worst Scrolling", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PolishMutedText)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            if (worstDay != null) {
                                Text(
                                    text = "${worstDay.totalCount} Reels",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PolishCharcoal
                                )
                                Text(
                                    text = formatDateString(worstDay.date),
                                    fontSize = 11.sp,
                                    color = PolishMutedText,
                                    fontWeight = FontWeight.SemiBold
                                )
                            } else {
                                Text("No historic logs", fontSize = 13.sp, color = PolishMutedText, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun getSavedLimit(context: Context): Int {
    return context.getSharedPreferences("auto_count_prefs", Context.MODE_PRIVATE).getInt("daily_limit", 50)
}

private fun formatDateString(dateStr: String): String {
    return try {
        val parser = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val formatter = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        val date = parser.parse(dateStr)
        if (date != null) formatter.format(date) else dateStr
    } catch (_: Exception) {
        dateStr
    }
}
